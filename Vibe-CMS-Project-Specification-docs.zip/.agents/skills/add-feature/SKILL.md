```yaml
---
name: add-feature
description: Use when asked to add a new feature not covered by existing task files
---
```

### Workflow for Adding a New Feature

When tasked with adding a new feature to VibeCMS, follow this sequence to ensure consistency with the architecture and sub-50ms TTFB performance goals:

1.  **Analyze Architecture & Scope**
    *   Review `internal/architecture.md` to determine if the feature belongs in the **Public Request Path** (performance-critical) or the **Background/Sidecar Layer** (asynchronous).
    *   Verify against `internal/api-spec.md` to see if a new API endpoint is required.
    *   Check `internal/folder-structure.md` to identify the correct directory for logic (e.g., `internal/cms/` for rendering, `internal/integrations/` for external APIs).

2.  **Define the Data Contract**
    *   If the feature requires persistence, define the model in `internal/db/models/`.
    *   Ensure any new JSONB fields follow the **Schema-on-Read** paradigm documented in `internal/architecture.md`.
    *   Run `go generate ./internal/db/...` if using GORM hooks or custom type-safe generators.

3.  **Implement the Feature**
    *   **Logic:** Implement core Go logic in the identified `internal/` packages.
    *   **API/Handlers:** If the feature requires UI interaction, define the handler in `internal/api/`. Use Fiber/Echo context correctly.
    *   **UI/Admin:** Create/Update `*.templ` files in `ui/components/` or `ui/layouts/`. Ensure all interactivity utilizes **HTMX** attributes (`hx-post`, `hx-swap`) rather than custom JS where possible.
    *   **Tengo Hooks:** If the feature is extensible, add a hook in the `internal/cms` renderer and expose it to the `pkg/tengo_ext/` module.

4.  **Write Tests**
    *   **Unit Tests:** Add tests in the same directory as the implementation (e.g., `feature_test.go`).
    *   **Integration Tests:** If the feature involves database or external services, add a test case in `internal/db/` or `internal/integrations/`.
    *   **Constraint Check:** Verify performance. If the feature sits in the "Vibe Loop," ensure execution overhead is $< 5\text{ms}$.

5.  **Verification**
    *   Run the full suite: `go test ./...`
    *   Verify the build: `go build -o bin/vibecms ./cmd/vibecms/main.go`
    *   Check for linting: `golangci-lint run ./...`

### Rules for Implementation
*   **No Global State:** Keep all services stateless to support 1:1 deployment architecture.
*   **Efficiency:** For high-traffic paths, use raw `pgx` queries instead of GORM if O(N) allocation occurs.
*   **Security:** Always use the `internal/auth` middleware for any endpoint modifying data.
*   **Documentation:** If adding a new configuration parameter, update `configs/config.yaml`.