```yaml
---
name: debug
description: Use when a bug is reported or tests are failing
---

1. **Reproduce the issue:**
    - If a failing test is suspected, run the specific test case:
      `go test -v ./internal/cms/...` or `go test -v ./internal/db/models/...`
    - If a runtime error occurs, check the application logs in `storage/logs/` or via Docker container logs:
      `tail -f storage/logs/system.log`
    - Isolate the request path by using `curl -v` or viewing the browser's Network tab to confirm the TTFB and HTTP status codes.

2. **Read relevant files:**
    - Use the file naming conventions and structure defined in `.agents/skills/project/folder-structure.md`.
    - If the issue is in the "Vibe Loop," examine `internal/cms/renderer.go` and `internal/cms/schema_transformer.go`.
    - For authentication/RBAC errors, check `internal/auth/middleware.go`.
    - For database-level issues, verify the GORM models in `internal/db/models/`.

3. **Identify the root cause:**
    - Determine if the issue is with **Schema Versioning** (check `schema_transformer.go`).
    - Verify if **Tengo scripts** are causing execution timeouts (check if `internal/pkg/tengo_ext/` logic is hitting the 15ms limit).
    - Check for **S3 integration** failures or credential mismatches in `internal/integrations/s3_storage.go`.
    - Do not confuse symptom manifestation (e.g., a template rendering error) with the cause (e.g., a malformed JSONB payload in `content_nodes`).

4. **Implement the minimal fix:**
    - Apply fixes within the specific boundary of the identified component.
    - Ensure Go 1.22.x compatibility.
    - Maintain statelessness: never hardcode configurations or file paths; use the environment-aware config loader.

5. **Verify:**
    - Run the full test suite to ensure no regressions: `go test ./...`
    - Check the "Vibe Loop" performance locally: `go run cmd/vibecms/main.go` and ensure the TTFB remains under the 50ms target.

6. **Commit:**
    - Describe the bug clearly.
    - Reference the specific component (e.g., `[cms]`, `[cron]`, `[api]`).
    - Example: `fix(cms): handle version 1.0 to 2.0 schema migration in renderer`