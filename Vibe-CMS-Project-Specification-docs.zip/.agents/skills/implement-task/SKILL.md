```yaml
---
name: implement-task
description: Use when asked to implement a specific task from .claude/tasks/
---

# Workflow for Task Implementation

1.  **Read Task:** Open the specific file in `.claude/tasks/` requested by the user.
2.  **Context Analysis:** Examine the "Context" and "What to implement" sections of the task file.
3.  **Implementation:**
    *   Navigate to the target file path in the project structure (e.g., `internal/cms/`, `internal/api/`, `themes/`, `ui/components/`).
    *   Apply the requested changes exactly as specified, respecting existing Go package boundaries and architectural constraints (e.g., no external API logic in `internal/cms`).
    *   Adhere to the project naming conventions and tech stack specifications defined in `docs/` or `tech-stack.md`.
4.  **Verification:**
    *   Execute the verification command provided in the task file (e.g., `go test ./...` or a custom build/check script).
    *   Address any test failures immediately.
5.  **Commit:** Perform an atomic commit with a message formatted as: `chore: implement task #[number] - [brief description]`.

## Operational Rules
*   **No Scope Creep:** Only implement features explicitly requested in the task file.
*   **Architecture Integrity:** Maintain clean separation between the "Vibe Loop" (public) and "Admin" paths.
*   **Performance:** Ensure all new code tracks toward the <50ms TTFB target; avoid unnecessary blocking I/O in hot paths.
*   **Tooling:** Use only approved technologies (Fiber/Echo, Jet, Templ, GORM, Tengo) as defined in `docs/tech-stack.md`.

## Example Usage
> User: "Implement task-001.md"
> AI: (Loads `.claude/tasks/task-001.md`, performs edits, runs `go test ./internal/db/...`, commits)
```