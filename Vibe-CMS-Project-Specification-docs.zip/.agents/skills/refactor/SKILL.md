```yaml
---
name: refactor
description: Use when asked to refactor or clean up code
---

### Workflow for Refactoring VibeCMS

1. **Target Identification:** Use the provided path (e.g., `internal/cms/renderer.go`) to locate the file. If no target is specified, list the relevant files in the `internal/` directory and ask the user to select one.
2. **Analysis:** Read the target file to detect "code smells":
    - **Performance Bottlenecks:** Anything risking the sub-50ms TTFB target (e.g., redundant DB queries, heavy linear loops, or blocking I/O).
    - **Complexity:** Functions > 40 lines.
    - **Logic Smells:** Deeply nested conditionals (try flat return-early patterns) or missing abstractions (if logic belongs in `internal/cms` vs `internal/integrations`).
3. **Architecture Validation:** Cross-reference the proposed change with `architecture.md` and `tech-stack.md`:
    - Ensure public rendering logic stays in `internal/cms`.
    - Ensure third-party API calls remain in `internal/integrations`.
    - Ensure background tasks are delegated to `internal/cron`.
4. **Implementation:**
    - Perform the smallest change possible to isolate logic or clean up flow.
    - Do **not** modify public API signatures (function arguments, exported types, exposed routes) to ensure project stability.
5. **Verification:**
    - Run the project test suite using `go test ./...` after every alteration.
    - Ensure the "Vibe Loop" (public rendering) performance profile remains unchanged.
6. **Commit:** Provide a clear, descriptive commit message detailing:
    - The specific smell identified (e.g., "extracted long method," "moved logic to decorator").
    - Why the move was made (e.g., "to maintain 50ms TTFB budget," "to better adhere to layered arch").

### Standard Refactoring Patterns for VibeCMS

- **Repository Abstraction:** If `internal/db` models are leaking, introduce an interface layer for the `Repository` pattern.
- **Service/Handler Split:** If an HTTP handler is doing calculations, move the logic to a service function.
- **Tengo Hook Extraction:** If Go code is repeatedly injecting context for `pre_render.tgo`, abstract the context creation into a setup function.
- **Schema Transformation:** If `internal/cms/schema_transformer.go` logic is expanding beyond simple mapping, move specific version upgrade patterns into their own internal helper methods.

### Rules of Engagement
- **No API Changes:** Never rename exported functions or modify existing routing parameters in `internal/api/` or `cmd/vibecms/main.go`.
- **Statelessness:** Ensure no refactoring introduces "disk-based" state persistence unless strictly within the `storage/` or `themes/` directories (as permitted by project docs).
- **Test-Driven Refactor:** Always verify using `go test` before considering the task complete.