```yaml
---
name: review-pr
description: Use when asked to review a pull request or set of changes
---

1. **Scope Identification**: Use `$ARGUMENTS` (PR number or branch) to identify the target files. Use `git diff` or file globbing to capture the scope of changes.
2. **Architecture Audit**:
    - Ensure all code conforms to the "Zero-Rebuild" philosophy (scripts in `themes/[name]/scripts/`).
    - Verify that no logic requiring a recompile of the Go binary is placed outside of `internal/`.
    - Check that the "Vibe Loop" (Public rendering path) remains free of blocking third-party API calls.
3. **Convention Enforcement**:
    - **Go**: Ensure `snake_case` naming.
    - **Templ**: Ensure `PascalCase` component naming.
    - **Jet**: `snake_case` templates in `themes/`.
    - **Migrations**: `YYYYMMDDHHMM_name.sql` format.
4. **Security & Performance Gatekeeping**:
    - **Auth**: Verify `internal/auth/middleware.go` is applied to all `/admin` routes.
    - **Secrets**: Check for hardcoded credentials (should use `config.yaml` or vault/env vars).
    - **TTFB Impact**: Ensure any new logic in the `PublicHandler` does not violate the sub-50ms constraint (avoid N+1 database queries; use `pgx` optimizations).
    - **Tengo Sandbox**: Verify that any `tgo` script access is routed through the `vibe_module` in `pkg/tengo_ext/`.
5. **Test Readiness**:
    - New features must include tests in appropriate `_test.go` files.
    - Verify that `internal/cron` tasks have error handling for provider outages (e.g., mail dispatch failures).
6. **Summary Categorization**:
    - **BLOCKER**: Security leaks, hardcoded credentials, direct DB access from Tengo, sync blocks in the public rendering loop, or missing Auth middleware on protected routes.
    - **WARNING**: Performance bottlenecks (TTFB risk), missing documentation for new themes or scripts, or violation of directory structure (e.g., placing logic in `ui/`).
    - **SUGGESTION**: Style improvements, code deduplication, or suggested usage of existing internal packages (`internal/integrations`).

---

**Example Reporting Format**:
- **BLOCKER**: [File Path] - Missing RBAC check on handler.
- **WARNING**: [File Path] - Potential N+1 query in `cms.renderer`.
- **SUGGESTION**: [File Path] - Refactor to use existing helper in `pkg/tengo_ext`.
```