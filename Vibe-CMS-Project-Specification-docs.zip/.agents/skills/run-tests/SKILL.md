```yaml
---
name: run-tests
description: Use when asked to run tests or verify a feature works
---

### Workflow for Testing VibeCMS

1. **Context Identification:** Verify the current Go environment version (`1.22.x`) and the project structure. All tests are located within the `internal/` or `pkg/` directories.
2. **Execute Full Test Suite:**
   - Run the command: `go test ./...`
   - For specific modules, use: `go test -v ./internal/[module_name]/...`
   - For data-intensive or integration tests (e.g., `internal/cms` or `internal/db`), ensure the test environment uses a local PostgreSQL/MinIO instance if applicable.
3. **Analyze Output:**
   - Identify failing tests by name, file path, and exact error message.
   - Look for "panic" or "assertion failures" in the test logs.
4. **Root Cause Analysis:**
   - Navigate to the source file indicated in the stack trace.
   - Cross-reference with `internal/cms/renderer.go` (the Vibe Loop) or `internal/cms/schema_transformer.go` to ensure the logic adheres to the project's performance and JSONB handling requirements.
5. **Implementation Fixes:**
   - Apply fixes in the implementation code (e.g., `internal/cms/`, `internal/db/`, `internal/cron/`).
   - If a test fails due to a schema mismatch, update the `Schema-on-Read` logic in the relevant service rather than changing the test assertions.
6. **Verification:**
   - Re-run the full suite: `go test ./...`
   - Confirm all packages return `PASS`.
7. **Reporting:**
   - Report the final count of passed vs. failed tests.
   - Summarize the nature of any fixes applied.

### Important Notes
- **Never bypass tests:** Do not comment out code to make tests pass.
- **Sidecar Logic:** If tests involve Cron systems or Async workers, ensure the tests properly await the final status or check the database/log entries.
- **Environment:** If tests depend on the `license.json` or `config.yaml`, ensure temporary test-specific variations are used in non-production local environments.
```