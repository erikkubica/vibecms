```yaml
---
name: add-feature
description: Add a new feature to the project
argument-hint: <feature description>
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---
```

# Implementing a New Feature in VibeCMS

To add a new feature, follow this tiered implementation process to maintain our strict performance (sub-50ms TTFB) and architectural constraints.

### 1. Architectural Impact Assessment
Before writing code, identify which layer of the VibeCMS component boundary the feature inhabits:
- **Public Render Path:** Must be optimized for speed. Avoid blocking I/O. Use `internal/cms` for logic.
- **Admin/UI Layer:** Use `ui/components` with `Templ`. HTMX/Alpine.js should drive interactivity.
- **Background Task:** Must live in `internal/cron` if it involves disk I/O, AI batching, or long-running tasks.
- **Integration Layer:** All third-party APIs must be implemented in `internal/integrations`.

### 2. Implementation Steps

1.  **Define Models:** If new database tables or JSONB fields are needed, update models in `internal/db/models/`. Use GORM tags for schema mapping.
2.  **Create Migrations:** Create a SQL file in `internal/db/migrations/` using the format `timestamp_feature_name.sql`.
3.  **Implement Integration/Logic:**
    - If it's a core handler, add it to `internal/api/` or `internal/cms/`.
    - If it's a helper for themes, add it to `pkg/tengo_ext/`.
4.  **UI Implementation:**
    - If providing an admin interface, create a new `Templ` component in `ui/components/`.
    - Use `HTMX` attributes in the template for async server communication.
5.  **Schema Transformation:** If your feature modifies the block data structure, add a transformation rule to `internal/cms/schema_transformer.go` to maintain backward compatibility.

### 3. Verification and Testing

1.  **Code Quality:** Ensure all new code adheres to the Go 1.22 format (e.g., proper scope for loop variables).
2.  **Schema Validation:** Manually verify that `internal/db/models` updates correctly populate your test database.
3.  **TTFB Baseline:** If the feature affects the "Vibe Loop", run a local load test to ensure the TTFB stays below the 50ms target.
4.  **Tengo Sandbox Test:** If the feature is accessible via scripting, write a test in `internal/cms/` or `pkg/tengo_ext/` to ensure the script cannot access unintended system properties.
5.  **Integration Test:** Add a test case for any new `internal/integrations` logic to ensure third-party API failures are handled via the standardized error format described in `api-spec.md`.

### 4. Running the Feature
- Run the application: `go run cmd/vibecms/main.go`
- For Admin UI changes, navigate to the local instance via your dev environment.
- If you added a `Cron` job, ensure it is registered in `internal/cron/scheduler.go`.

---

**Feature Request:** $ARGUMENTS

*To begin, evaluate if $ARGUMENTS requires a database change. If so, start by generating your migration script.*