```yaml
---
name: fix-bug
description: Fix a bug in the project
argument-hint: <bug description or error message>
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---
```

To fix a bug in VibeCMS, follow this structured workflow. This approach ensures we maintain the sub-50ms TTFB requirement and respect the project's stateless, single-instance architecture.

### 1. Reproduce the Issue
*   **Search logs:** Check `storage/logs/` for application-level errors or stack traces.
*   **Check Agency API:** If the bug relates to performance or health, query the status endpoint:
    `curl -H "X-Vibe-Agency-Key: <your-key>" http://localhost:8080/api/v1/management/health`
*   **Create a Reproduction Script/Test:**
    *   If it’s a UI issue, navigate to `ui/components/` and check the relevant `.templ` code.
    *   If it’s a rendering issue in the "Vibe Loop", verify your fix by creating/debugging a test case in `internal/cms/renderer_test.go` (if available) or by modifying code in `internal/cms/`.
    *   If it relates to data (Postgres JSONB), check specific models in `internal/db/models/`.

### 2. Identify the Root Cause
*   **Use `grep` to locate definitions:**
    `grep -r "error_message_or_keyword" internal/`
*   **Check the Rendering Pipeline:** If the site is failing to render, check `internal/cms/renderer.go` and `internal/cms/schema_transformer.go` to see if the JSONB schema mismatch is causing a failure in the "Vibe Loop".
*   **Verify Tengo scripts:** If the issue involves custom logic, check the theme scripts:
    `ls themes/[your-active-theme]/scripts/`
    Verify if `pre_render.tgo` is causing an execution timeout (15ms budget).

### 3. Implement the Fix
*   **Follow Architecture Boundaries:**
    *   **Logic changes:** Modify files in `internal/`.
    *   **External API changes:** Strictly use `internal/integrations/`.
    *   **UI/Admin changes:** Modify `ui/components/` (Templ) or `ui/assets/` (HTMX/Alpine).
*   **Apply "Schema-on-Read" safely:** If a fix requires a database schema change, execute it via versioned migration files in `internal/db/migrations/` (format: `YYYYMMDDHHMM_name.sql`).
*   **Do not introduce state:** Ensure new variables are not persisted locally; continue using PostgreSQL or S3 as defined in `tech-stack.md`.

### 4. Verify the Fix
*   **Unit Tests:** Run relevant tests for the modified internal package:
    `go test -v ./internal/[modified_package]/...`
*   **Verify TTFB:** Use `curl -w "@scripts/curl-format.txt" -o /dev/null -s http://localhost:8080/` to ensure your fix has not regressed the sub-50ms TTFB target.
*   **Integration Check:** If you modified the Admin UI, ensure the `BlockEditor` (`ui/components/BlockEditor.templ`) remains functional and drag-and-drop works with `SortableJS`.

### 5. Finalize
*   **Format:** Run `go fmt ./...` before committing.
*   **Document:** If you added a significant dependency or changed an API endpoint, update `internal/api/api_spec.md` (or the relevant documentation section).

**Current Argument:** $ARGUMENTS