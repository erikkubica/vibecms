```yaml
---
name: review-code
description: Review code for correctness, security, and consistency with project conventions
argument-hint: <file path or feature to review>
allowed-tools: Read, Glob, Grep
---
```

# Code Review Protocol for VibeCMS

Use this guide to review any code (Go files, Templ components, or Tengo scripts) for the VibeCMS project.

### 1. Correctness & Architecture check
- **Performance Path:** If reviewing any code in `internal/cms` or critical rendering paths, ensure it adheres to the "Vibe Loop" (fetch JSONB -> Transform -> Render). 
- **Sub-50ms TTFB:** Does the code perform heavy operations? If so, verify it is offloaded to `internal/cron` or a background routine. Ensure raw `pgx` is used rather than heavy GORM abstraction for public-facing read paths.
- **Statelessness:** Ensure no `os.OpenFile` or local-disk persistence is used for media. Every file operation should interface with the `internal/integrations/s3_storage.go` client.
- **Tengo/Scripting:** Verify scripts do not attempt to bypass the sandbox. Check that they interact only with the `vibe` object provided in `pkg/tengo_ext/vibe_module.go`.

### 2. Security Requirements
- **Input Validation:** Ensure all `PATCH/POST` endpoints validate JSON inputs against the project's expected structure.
- **RBAC:** Verify that handlers check the `role` using the `internal/auth/middleware.go` before proceeding.
- **API Keys:** If the code is in `internal/api`, verify it requires the `X-Vibe-Agency-Key` header and performs authorization checks.
- **Execution Limits:** For any code executing arbitrary content (Tengo or template evaluation), look for execution timeouts or memory overhead checks to prevent resource exhaustion.

### 3. Consistency with Conventions
- **Naming:**
    - Go: `snake_case.go`
    - Templ: `PascalCase.templ`
    - Scripts: `snake_case.tgo`
- **Component Placement:**
    - Are third-party API calls (Resend, Ahrefs) restricted to `internal/integrations`?
    - Is UI logic residing in `ui/`?
    - Are theme-specific logic files isolated in `themes/`?
- **Schema Usage:** Check for "Schema-on-Read" implementations in `internal/cms/schema_transformer.go` if the code alters content structure.

### 4. Review Steps
1. **Identify the Scope:** Run `grep` to find related files if the `$ARGUMENTS` is a feature folder (e.g., "media processor").
2. **Review the Flow:** Trace the data flow. If it involves a database, does it use the correct JSONB model in `internal/db/models`?
3. **Check for "Bloat":** Are there unnecessary imports or dependencies that don't match the `tech-stack.md`?
4. **Validation:** Specifically look for error handling; every `5xx` scenario must return a valid error envelope (see `api-spec.md` Error Format).

---
**Run this command:** `review-code <path>`
- *Example:* `review-code internal/cms/renderer.go`
- *Example:* `review-code internal/cron/backup_job.go`