```yaml
---
name: write-tests
description: Write tests for a feature or component
argument-hint: <feature, function, or component to test>
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Writing Tests for VibeCMS

Follow these steps to ensure VibeCMS maintains its sub-50ms TTFB target and high reliability.

### 1. Identify the Scope
Ensure you are targeting the correct layer:
- **Core Engine (`internal/cms`):** Use unit tests to verify "Schema-on-Read" transformations and the "Vibe Loop."
- **Integrations (`internal/integrations`):** Use interface-mocking to verify S3, Resend, and SEO API clients.
- **Components (`ui/components`):** Verify `Templ` component logic via functional integration tests.

### 2. Standard Testing Patterns
VibeCMS uses the standard Go `testing` package with `testify/assert` for assertions.

*   **Unit Tests:** Create `filename_test.go` in the same directory as the source.
*   **Integration Tests:** Create files in `internal/db/` or `internal/cms/` using the `_test.go` suffix.
*   **Infrastructure Mocks:** Use `internal/db/postgres.go` to spin up a ephemeral Docker-based container if your test requires real PostgreSQL JSONB operations.

### 3. Step-by-Step Instructions

#### A. Understand the Component
- Read the relevant file (e.g., `internal/cms/renderer.go`).
- Identify external dependencies (e.g., *Is it hitting the database?* *Is it calling Tengo?*).

#### B. Setup the Test File
If testing `internal/cms/schema_transformer.go`, create `internal/cms/schema_transformer_test.go`:
```go
package cms

import (
    "testing"
    "github.com/stretchr/testify/assert"
)

func TestSchemaTransformation(t *testing.T) {
    // 1. Setup mock JSONB data
    // 2. Call the transformation function
    // 3. Assert deep equality against expected schema version
}
```

#### C. Writing the Test
- **For `internal/cms`:** Use `testify/mock` to mock database interfaces.
- **For `pkg/tengo_ext`:** Test Tengo modules by initializing a `tengo.VM` and executing small snippets to verify your custom Vibe-module functions have the correct scope.
- **For `ui/components`:** Use the `templ` test helpers to render components into a string buffer and check for expected HTML output.

#### D. Running the Test Suite
Run tests locally with clean environment variables (ensuring `DB_URL` points to a test schema):
```bash
# Run all tests in the project
go test ./... -v

# Run tests for a specific feature (e.g., cms)
go test ./internal/cms/... -v
```

### 4. Important Considerations
- **TTFB Testing:** For critical path code in `internal/cms`, always include a benchmark test using `testing.B` to ensure execution remains near the sub-15ms budget.
- **No Side-Effects:** Ensure your tests do not persist data to production-like storage. Always use `internal/db/models` with a temporary, wiped test database.
- **Mocking:** Do not use production API keys for your integration tests. Mock the `internal/integrations` interfaces to verify success/failure responses without hitting live services.

### 5. Verification
After writing your test, run:
`go test -short ./...` (executes only unit tests)
`go test ./...` (executes all including integration)

Use `$ARGUMENTS` to specify the module path or component, and review the existing tests in that directory as a template for style and mocking patterns.