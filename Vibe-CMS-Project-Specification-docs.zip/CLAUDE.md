# VibeCMS
A high-performance, AI-native Go-based CMS optimized for agencies, featuring a sub-50ms TTFB target and a block-based JSON editor.

## Tech Stack
- **Language**: Go 1.22.x
- **Frameworks**: Fiber 2.52.x (or Echo 4.12.x)
- **Templating**: Jet 6.0.x (Public), Templ 0.2.x (Admin)
- **Database**: PostgreSQL 16.x (JSONB storage)
- **Scripting Engine**: Tengo 2.13.x
- **Frontend**: HTMX 2.0.x, Alpine.js 3.14.x, SortableJS 1.15.x
- **Infrastructure**: S3-compatible storage (R2/Spaces/MinIO), libvips (WebP processing)
- **Integrations**: Resend API, Ahrefs/Semrush API

## Architecture Overview
VibeCMS uses a single-binary, stateless architecture designed for 1:1 site-to-instance deployments.
- **Vibe Loop**: Public request path matches URLs to `content_nodes` (Postgres JSONB), transforms data via Schema-on-Read, executes `pre_render.tgo` (Tengo), and renders via Jet for sub-50ms TTFB.
- **Admin UI**: Server-rendered components via Templ, HTMX for partial updates, and Tiptap/ProseMirror for rich text.
- **Extensibility**: Custom logic is injected via `.tgo` scripts stored in `/themes/{name}/scripts/`, avoiding Go recompilation.
- **Background Tasks**: Internal Go-routine based workers (Cron) handle backups, mail logging, and image optimization (libvips), ensuring they do not block the request loop.

## Folder Structure
- `cmd/`: Application entry point.
- `internal/`: Private logic (API, Auth, CMS rendering, DB models, Cron).
- `pkg/`: Extensions for Tengo scripting VM.
- `ui/`: Admin UI components (Templ) and assets (HTMX/Alpine).
- `themes/`: Client-facing theme files (Jet templates, .tgo scripts, theme metadata).
- `configs/`: Default configuration files and license templates.
- `scripts/`: Build and deployment helper scripts.

## Key Conventions
- **No Native Multi-site**: Every instance is independent (1 deployment = 1 website).
- **Schema-on-Read**: Do not run automated schema migrations on JSONB content blocks; use versioning maps instead to maintain performance.
- **Stateless Media**: All media must reside in S3-compatible storage; local storage is for development (MinIO) only.
- **Performance First**: The Rendering Pipeline must complete in <50ms. Heavy logic is prohibited in the request cycle—use Cron workers for async tasks.
- **Type Safety**: Use `Templ` for Admin UI components to catch errors at compile-time.
- **Scripting Constraints**: Tengo scripts must not call SQL directly; they interact with a restricted `vibe` global object provided by the engine.
- **AI Integration**: AI-generated content (SEO/Blocks) must remain in a "Suggestion" state until the user explicitly commits it via the Admin UI.
- **Naming**: Use `snake_case` for Go/Jet/Tengo, `PascalCase` for Templ components, and `kebab-case` for CSS/JS assets.