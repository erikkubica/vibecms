# VibeCMS API Specification

## About This Document

**Purpose:** REST endpoint contracts for frontend and external consumers. Defines the interface between backend services and clients.

**How AI tools should use this:** Use the exact endpoint paths, HTTP methods, and request/response shapes when generating API calls or handlers.

**Consistency requirements:** Every endpoint must correspond to a feature in product-requirements.md; request/response fields must map to tables in database-schema.md; service boundaries must match architecture.md.

The VibeCMS API is designed to support a high-performance, single-instance CMS architecture. It provides specialized interfaces for public content delivery, a robust administrative suite powered by HTMX/Alpine.js, and a secure management gateway for agencies. All endpoints prioritize the sub-50ms Time to First Byte (TTFB) target by utilizing PostgreSQL JSONB for flexible data retrieval and in-memory caches.

---

The API is organized into four logical groups: Authentication (Identity management), Content (Node and Block management), Media (S3-compatible asset management), and Agency (Monitoring and Health). Authentication is handled via secure session cookies for the Admin UI and API Keys for the Agency Management endpoints.

## 1. Authentication & Profile
Fulfills requirements: REQ-RBAC-01, REQ-SEC-02

### POST /api/v1/auth/login
Authenticates a user and establishes a session.
- **Auth Requirement:** Public
- **Request Body:**
    - `email` (string, required)
    - `password` (string, required)
- **Response Body (200):**
    - `user_id` (uuid)
    - `role` (string)
    - `email` (string)
- **Status Codes:** 200 (Success), 401 (Unauthorized), 429 (Too Many Requests - Brute force protection)

### POST /api/v1/auth/logout
Terminates the current session.
- **Auth Requirement:** Authenticated
- **Request Body:** None
- **Response Body (200):**
    - `message` (string)
- **Status Codes:** 200 (Success)

### GET /api/v1/me
Retrieves the profile of the currently logged-in user.
- **Auth Requirement:** Authenticated
- **Request Body:** None
- **Response Body (200):**
    - `id` (uuid)
    - `email` (string)
    - `role_slug` (string)
    - `metadata` (object)
- **Status Codes:** 200 (Success), 401 (Unauthorized)

### PUT /api/v1/me
Updates the current user's profile metadata or password.
- **Auth Requirement:** Authenticated
- **Request Body:**
    - `password` (string, optional)
    - `metadata` (object, optional)
- **Response Body (200):**
    - `id` (uuid)
    - `updated_at` (timestamp)
- **Status Codes:** 200 (Success), 400 (Invalid Data)

---

## 2. Content Nodes (Universal Nodes)
Fulfills requirements: REQ-CORE-01, REQ-SEO-01, REQ-LANG-01

### GET /api/v1/nodes
Lists content nodes with filtering and pagination.
- **Auth Requirement:** Authenticated
- **Parameters:**
    - `page` (int, default: 1)
    - `per_page` (int, default: 20)
    - `type` (string: page|post|custom)
    - `status` (string: draft|published|archived)
    - `q` (string, search slug or title)
    - `locale` (string, e.g., "en")
- **Response Body (200):**
    - `items` (array of objects: id, slug, node_type, status, language_code, created_at)
    - `total_count` (int)
- **Status Codes:** 200 (Success)

### GET /api/v1/nodes/{id}
Retrieves a single node including full JSONB block data.
- **Auth Requirement:** Authenticated (Public route is internal to Go binary)
- **Response Body (200):**
    - `id` (uuid)
    - `slug` (string)
    - `node_type` (string)
    - `status` (string)
    - `blocks_data` (array of objects)
    - `metadata` (object)
    - `schema_version` (int)
- **Status Codes:** 200 (Success), 404 (Not Found)

### POST /api/v1/nodes
Creates a new content node.
- **Auth Requirement:** Authenticated (Admin/Editor)
- **Request Body:**
    - `slug` (string, required)
    - `node_type` (string, required)
    - `language_code` (string, required)
    - `parent_id` (uuid, optional)
- **Response Body (201):**
    - `id` (uuid)
- **Status Codes:** 201 (Created), 409 (Conflict - Slug exists)

### PATCH /api/v1/nodes/{id}
Partial update of node content, status, or SEO metadata.
- **Auth Requirement:** Authenticated (Admin/Editor)
- **Request Body:**
    - `slug` (string, optional)
    - `status` (string, optional)
    - `blocks_data` (array, optional)
    - `metadata` (object, optional)
- **Response Body (200):**
    - `id` (uuid)
    - `updated_at` (timestamp)
- **Status Codes:** 200 (Success), 422 (Unprocessable Entity - Schema mismatch)

### DELETE /api/v1/nodes/{id}
Deletes a node. (Note: Production implementations use soft-delete by updating status to 'archived').
- **Auth Requirement:** Authenticated (Admin)
- **Response Body (204):** Empty
- **Status Codes:** 204 (No Content)

---

## 3. Media Manager
Fulfills requirements: REQ-MEDIA-01, REQ-PERF-02

### GET /api/v1/media
Lists uploaded media assets.
- **Auth Requirement:** Authenticated
- **Parameters:**
    - `page` (int)
    - `per_page` (int)
    - `type` (string, e.g., "image/webp")
    - `q` (string, search filename/alt)
- **Response Body (200):**
    - `items` (array of objects: id, filename, s3_key, file_type, byte_size, metadata)
    - `total` (int)
- **Status Codes:** 200 (Success)

### POST /api/v1/media/upload
Uploads a file and triggers asynchronous WebP optimization.
- **Auth Requirement:** Authenticated
- **Request Body:** Multipart Form Data (`file`)
- **Response Body (201):**
    - `id` (uuid)
    - `status` (string: "processing")
    - `s3_key` (string)
- **Status Codes:** 201 (Created), 415 (Unsupported Media Type)

### PATCH /api/v1/media/{id}
Update media metadata (Alt text, focal points).
- **Auth Requirement:** Authenticated
- **Request Body:**
    - `metadata` (object)
- **Response Body (200):**
    - `id` (uuid)
- **Status Codes:** 200 (Success)

### DELETE /api/v1/media/{id}
Deletes a media asset from DB and S3.
- **Auth Requirement:** Authenticated (Admin)
- **Status Codes:** 204 (No Content)

---

## 4. Agency & System Operations
Fulfills requirements: REQ-AGNCY-01, REQ-COMM-01, REQ-CRON-01

### GET /api/v1/management/health
High-resolution telemetry for external dashboards.
- **Auth Requirement:** API Key (`X-Vibe-Agency-Key`)
- **Response Body (200):**
    - `status` (string)
    - `uptime_seconds` (int)
    - `version` (string)
    - `metrics` (object: ttfb_p95_ms, memory_mb, cpu_pct)
    - `services` (object: postgres, s3, cron)
- **Status Codes:** 200 (Success), 403 (Invalid Key)

### GET /api/v1/management/email-logs
Retrieves audit logs of all outgoing communications.
- **Auth Requirement:** API Key or Authenticated Admin
- **Parameters:**
    - `page` (int)
    - `status` (string: sent|failed|pending)
- **Response Body (200):**
    - `items` (array: id, recipient, subject, status, provider, created_at)
- **Status Codes:** 200 (Success)

### POST /api/v1/management/backups
Manually triggers an S3 database dump.
- **Auth Requirement:** API Key (`X-Vibe-Agency-Key`)
- **Response Body (202):**
    - `task_id` (uuid)
    - `message` (string)
- **Status Codes:** 202 (Accepted)

---

## Error Response Format
All non-2xx responses follow this standard envelope:

```json
{
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "The slug field is required.",
    "details": {
      "slug": "missing_required_field"
    },
    "trace_id": "vibe_abc123"
  }
}
```

## HTTP Status Code Summary

| Status Code | Meaning in This API |
|-------------|---------------------|
| 200 | Success with response body |
| 201 | Resource successfully created |
| 202 | Task accepted for background processing (Backups, AI) |
| 204 | Success, no content returned (Delete) |
| 400 | Bad Request - Invalid parameters |
| 401 | Unauthorized - Valid session or API key missing |
| 403 | Forbidden - Authenticated but insufficient permissions |
| 404 | Resource not found |
| 409 | Conflict - Resource (like slug) already exists |
| 422 | Unprocessable Entity - JSON Schema validation failure |
| 429 | Too Many Requests - Brute force or Rate limit hit |
| 500 | Internal Server Error - Logic or Database failure |
| 503 | Service Unavailable - Maintenance or DB connection lost |