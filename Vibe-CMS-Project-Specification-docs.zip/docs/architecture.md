# VibeCMS System Architecture

## About This Document

**Purpose:** Component diagram and data flow defining how the system is structured. The authoritative reference for system boundaries and communication patterns.

**How AI tools should use this:** Reference this document before designing new components; ensure new code fits within existing component boundaries.

**Consistency requirements:** Components must use only technologies from tech-stack.md; data stores must match tables in database-schema.md; service boundaries must align with endpoints in api-spec.md.

VibeCMS is architected as a high-performance, single-binary Go application optimized for 1:1 site-to-instance deployments. To achieve the sub-50ms TTFB target, the system strictly separates the high-speed public rendering path from the heavier administrative and background operations. By using a "Sidecar" pattern for resource-intensive tasks like image optimization and backups, the core web server remains responsive under load. This architecture prioritizes statelessness, offloading all binary assets to S3-compatible storage and leveraging PostgreSQL's JSONB features to provide a flexible, schema-on-read content model.

---

### System Component Diagram

```mermaid
graph TB
    subgraph "External Entities"
        User["Public Visitor"]
        Admin["Agency Editor"]
        Dash["Agency Dashboard (External)"]
        S3["S3/R2 Storage"]
        LLM["AI Provider (OpenAI/Anthropic)"]
    end

    subgraph "VibeCMS Instance (Go Binary)"
        direction TB
        
        subgraph "Web Layer (Fiber/Echo)"
            Router["Request Router"]
            Auth["Security & RBAC Middleware"]
            PublicHandler["Public Rendering Controller"]
            AdminHandler["Admin UI Controller"]
            AgencyAPI["Management API Endpoint"]
        end

        subgraph "Logic Engines"
            TengoVM["Tengo Scripting VM (Zero-Rebuild)"]
            JetEngine["Jet Template Engine"]
            SemaRead["Schema-on-Read Transformer"]
        end

        subgraph "Background Services (Sidecar)"
            Cron["Internal Cron Scheduler"]
            MediaProcessor["WebP Optimizer (libvips)"]
            MailWorker["Async Mail Dispatcher"]
        end
    end

    subgraph "Data Tier"
        Postgres[("PostgreSQL 16+")]
    end

    %% Public Traffic Flow
    User -->|GET| Router
    Router --> PublicHandler
    PublicHandler --> TengoVM
    PublicHandler --> SemaRead
    SemaRead --> Postgres
    PublicHandler --> JetEngine
    JetEngine -->|Sub-50ms HTML| User

    %% Admin Traffic Flow
    Admin -->|HTMX/Alpine| AdminHandler
    AdminHandler --> Auth
    AdminHandler --> Postgres
    AdminHandler --> LLM
    AdminHandler --> MediaProcessor

    %% Background Logic
    MediaProcessor --> S3
    Cron --> Postgres
    Cron --> MailWorker
    Dash -->|X-API-KEY| AgencyAPI
    AgencyAPI --> Postgres
```

### Data Flow

#### 1. The "Vibe Loop" (Public Page Render)
This is the performance-critical path representing the core value of sub-50ms TTFB.
1.  **Entry:** Router matches the URL slug against a cache-prime lookup table.
2.  **Fetch:** `PublicHandler` executes a single optimized query to fetch `blocks_data` (JSONB) and `metadata` from `content_nodes`.
3.  **Transform:** `SemaRead` evaluates the `version_id`. If outdated, it applies in-memory mapping to the JSON structure.
4.  **Extend:** `TengoVM` executes the theme's `pre_render.tgo` (max 15ms) to inject dynamic data into the context.
5.  **Render:** `JetEngine` iterates JSON blocks, fetching pre-compiled `.jet` templates from memory.
6.  **Return:** The resulting HTML fragment is streamed to the user.

#### 2. Media Upload & WebP Optimization
1.  **Entry:** Editor drops an image into the Admin UI (`multipart/form-data`).
2.  **Storage:** The raw file is immediately pushed to the `originals/` prefix in **S3**.
3.  **Queue:** An "Optimization Job" is added to the internal **Cron** worker pool.
4.  **Process:** `MediaProcessor` uses `libvips` to resize and convert the image to WebP format.
5.  **Finalize:** Optimized variants are pushed to the `processed/` prefix in **S3**, and the `media_assets` table is updated in **Postgres**.

#### 3. AI-Native SEO Generation
1.  **Request:** Editor clicks "AI Suggest" in the Admin SEO panel.
2.  **Context:** `AdminHandler` gathers all text-based JSON keys from the current page's `blocks_data`.
3.  **Inference:** The context and schema are sent to the **LLM** via HTTPS.
4.  **Patch:** The LLM returns a structured JSON; `AdminHandler` validates this against the SEO schema and stores it in the `seo_suggestions` JSONB column.
5.  **Review:** The Editor reviews the suggestion and "Applies" it via an HTMX swap, moving data to the primary `metadata` field.

### Error Handling

| Component | Failure | Detection | Recovery / Handling |
| :--- | :--- | :--- | :--- |
| **Tengo VM** | Script Timeout / Error | Execution deadline exceeded (15ms) | The script is killed; system logs error and falls back to raw block data (page still renders). |
| **PostgreSQL** | Connection Loss | Health check / `pgx` pool error | `AgencyAPI` flags "Unhealthy"; Fiber returns 503 Maintenance page to users. |
| **S3 Storage** | Provider Timeout | S3 SDK Error | Media Manager UI displays "Storage Offline"; public site serves broken image icons or uses CDN fallback. |
| **SemaRead** | Version Mismatch | Unregistered version ID | Renders the block using a default "Deprecated Block" template to prevent total page crash. |
| **Mail Worker** | Provider 5xx (Resend) | Non-200 HTTP status | Task remains in `failed` state in `email_logs`; Cron retries 3 times before manual intervention. |

### Security Boundaries

*   **Public Zone:** Only the Route-matched public handlers and the `/assets` directory are accessible without authentication.
*   **Admin Zone:** Accessible only via `/admin`. Enforced by `Auth` middleware using Argon2id session tokens. RBAC restricts "Editor" roles from accessing "System/Tengo" settings.
*   **Agency API Zone:** Accessible via `/api/v1/management`. Requires `X-Vibe-Agency-Key` in the header. IP whitelisting is recommended at the infrastructure level (e.g., Cloudflare/WAF).
*   **Encrypted Data:** 
    *   **In Transit:** TLS 1.3 is required for all public and admin traffic.
    *   **At Rest (Postgres):** Sensitive integration keys (Resend API, S3 Secrets) are encrypted using AES-256-GCM before storage in JSONB.
    *   **At Rest (S3):** All backups pushed to S3 are encrypted via the sidecar using a system-level passphrase.

### Architected Decisions

*   **Synchronous Rendering vs. Edge Caching:** While many CMSs rely on aggressive CDN caching, VibeCMS focuses on **Origin Speed** (sub-50ms). We chose this because agency clients often require real-time content updates and dynamic logic (Tengo) that simple edge-caching breaks.
*   **Postgres JSONB over NoSQL:** We use PostgreSQL JSONB because it allows us to maintain strict relational integrity for users/roles while getting the flexibility of a document store for "Block" data. This avoids the operational complexity of managing two different database types.
*   **In-Memory Template Cache:** Jet templates are compiled to bytecode and stored in RAM at startup. This decision was made because disk I/O is the primary enemy of the 50ms TTFB goal; by the time a request hits, the "template logic" should already be in CPU-readable memory.
*   **Internal Sidecar Task Management:** We avoid external message queues (like Redis/RabbitMQ) to keep the "1 Deployment per Site" constraint easy to maintain. A single Go binary that manages its own background workers is significantly easier for an agency to deploy and monitor than a distributed microservices stack.