# VibeCMS Database Schema

## About This Document

**Purpose:** Authoritative table definitions and relationships. Every database interaction in the codebase must conform to this schema.

**How AI tools should use this:** Reference table names, column names, and types from this document when writing queries or ORM models.

**Consistency requirements:** Data stores must match components defined in architecture.md; request and response fields in api-spec.md must trace to columns in these tables.

This document describes the structure of the VibeCMS database. It is designed for high-performance retrieval and flexibility, primarily utilizing PostgreSQL's JSONB capabilities to allow content to evolve without expensive database migrations. Most public-facing requests involve single-row lookups to ensure we meet our 50ms response time target.

---

## Entity Relationship Overview

VibeCMS uses a "Universal Node" architecture. `content_nodes` is the heart of the system, storing pages, posts, and custom entities. 

- **Users** belong to **Roles** and author **Content Nodes**.
- **Content Nodes** contain **Blocks** (JSONB) and link to **Media Assets**.
- **Taxonomy Nodes** (Categories/Tags) are associated with **Content Nodes** via a join table.
- **Node Versions** archive historical states of a Node’s content.
- **Email Logs** and **Audit Logs** track system activity and communications.

---

## Table Definitions

### users
Stores administrative and editor accounts.
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL, -- Argon2id
    full_name VARCHAR(100) NOT NULL,
    role_id VARCHAR(50) NOT NULL, -- references logic in security.md (Admin, Agency-Manager, Editor)
    status VARCHAR(20) DEFAULT 'active', -- active, suspended
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### content_nodes
The central table for all routable content. Designed for sub-50ms lookup.
```sql
CREATE TABLE content_nodes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(255) NOT NULL,
    node_type VARCHAR(50) NOT NULL DEFAULT 'page', -- page, post, custom_entity
    parent_id UUID REFERENCES content_nodes(id) ON DELETE SET NULL,
    language_code VARCHAR(5) NOT NULL DEFAULT 'en',
    status VARCHAR(20) NOT NULL DEFAULT 'draft', -- draft, published, archived, scheduled
    blocks_data JSONB NOT NULL DEFAULT '[]', -- The actual page content
    metadata JSONB NOT NULL DEFAULT '{}', -- SEO, OpenGraph, Schema.org
    seo_suggestions JSONB DEFAULT '{}', -- Temporary AI-generated metadata
    schema_version INT NOT NULL DEFAULT 1, -- For Schema-on-Read transformation
    author_id UUID REFERENCES users(id),
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_slug_per_locale UNIQUE (slug, language_code)
);
CREATE INDEX idx_nodes_lookup ON content_nodes (slug, language_code, status);
CREATE INDEX idx_nodes_type ON content_nodes (node_type);
```

### node_versions
Archival table for point-in-time content recovery.
```sql
CREATE TABLE node_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    node_id UUID NOT NULL REFERENCES content_nodes(id) ON DELETE CASCADE,
    blocks_data JSONB NOT NULL,
    metadata JSONB NOT NULL,
    version_label VARCHAR(100), -- e.g., "Milestone Save"
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);
```

### taxonomy_nodes
Stores categories, tags, and custom taxonomies.
```sql
CREATE TABLE taxonomy_nodes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL,
    taxonomy_type VARCHAR(50) NOT NULL DEFAULT 'category', -- category, tag, brand
    description TEXT,
    language_code VARCHAR(5) NOT NULL DEFAULT 'en',
    UNIQUE (slug, taxonomy_type, language_code)
);
```

### node_taxonomy_map
Join table linking content to taxonomies.
```sql
CREATE TABLE node_taxonomy_map (
    node_id UUID NOT NULL REFERENCES content_nodes(id) ON DELETE CASCADE,
    taxonomy_id UUID NOT NULL REFERENCES taxonomy_nodes(id) ON DELETE CASCADE,
    PRIMARY KEY (node_id, taxonomy_id)
);
```

### media_assets
Metadata for files stored in S3-compatible storage.
```sql
CREATE TABLE media_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    filename VARCHAR(255) NOT NULL,
    s3_key TEXT NOT NULL, -- Path in bucket
    mime_type VARCHAR(100) NOT NULL,
    file_size_bytes BIGINT NOT NULL,
    dimensions_json JSONB, -- {width: 1024, height: 768}
    alt_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    uploaded_by UUID REFERENCES users(id)
);
```

### email_logs
Audit trail for all outgoing communications (SMTP/Resend).
```sql
CREATE TABLE email_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient VARCHAR(255) NOT NULL,
    subject TEXT NOT NULL,
    body_html TEXT,
    provider VARCHAR(20) NOT NULL, -- smtp, resend
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, sent, failed, bounced
    provider_id TEXT, -- External ID from Resend/SMTP
    error_log TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at TIMESTAMPTZ
);
```

### system_audit_log
Security and activity log for agency-level auditing.
```sql
CREATE TABLE system_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    event_type VARCHAR(50) NOT NULL, -- LOGIN, NODE_UPDATE, SCRIPT_EXEC, BACKUP_TRIGGER
    resource_id VARCHAR(100), -- ID of the node/asset affected
    ip_address INET,
    user_agent TEXT,
    metadata JSONB, -- Detailed diffs or error stacks
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

### Data Dictionary

| Business Term | Table | Column | Notes |
|---------------|-------|--------|-------|
| "Active user" | users | status | status = 'active' |
| "Live Page" | content_nodes | status | status = 'published' |
| "Block Content"| content_nodes | blocks_data | JSONB array of content fragments |
| "SEO Tags" | content_nodes | metadata | Stores Title, Desc, and Schema.org |
| "Slug" | content_nodes | slug | The URL segment (e.g., 'home') |
| "Category" | taxonomy_nodes | taxonomy_type | taxonomy_type = 'category' |
| "WebP Path" | media_assets | s3_key | Resolved via CDN URL helper |

### Seed Data Examples

**users**
| id | email | role_id | status |
|----|-------|---------|--------|
| `550e...` | admin@agency.com | Admin | active |
| `661f...` | editor@client.sk | Editor | active |

**content_nodes (Example Page)**
| slug | node_type | language_code | blocks_data |
|------|-----------|---------------|-------------|
| `home` | page | en | `[{"type": "hero", "values": {"title": "Hello Vibe"}}]` |
| `o-nas`| page | sk | `[{"type": "text", "values": {"content": "Sme Vibe"}}]` |

---

### Soft-Delete Strategy
VibeCMS uses **Hard Deletes** for system logs (Audit/Email) after a retention period, but uses a **Status-based Soft Delete** for Content Nodes.
- In `content_nodes`, rows with `status = 'archived'` are considered soft-deleted.
- Queries for the public frontend must explicitly include `WHERE status = 'published'`.

### Audit Trail
- **Tables with Logging:** `content_nodes`, `users`, `media_assets`, and `taxonomy_nodes`.
- **Event Storage:** All significant INSERT, UPDATE, and DELETE events are recorded in the `system_audit_log` table.
- **Tengo Scripts:** Any system modification triggered by a Tengo script will include `metadata -> 'source': 'tengo_script'` in the audit log.