# VibeCMS Deployment Guide

## About This Document

**Purpose:** Step-by-step environment setup and deployment procedures for every environment this project targets. The authoritative runbook for getting the application running.

**How AI tools should use this:** Reference this document when scaffolding CI/CD pipelines, Dockerfiles, environment configs, or deployment scripts; do not invent configuration values not listed here.

**Consistency requirements:** Technology choices must match tech-stack.md; service names must match architecture.md; environment variables must map to the configuration requirements implied by api-spec.md and database-schema.md.

VibeCMS is designed to be a high-performance, stateless Go application. This guide covers the deployment of the single-binary instance. Because the application targets a sub-50ms Time to First Byte (TTFB), the deployment emphasizes proximity to the database and optimized asset handling. Every instance is treated as an independent deployment to ensure data isolation and performance stability for agency clients.

---

### Prerequisites

The following tools must be installed and verified before beginning the setup.

*   **Go 1.22.x**: The core runtime.
    *   Verification: `go version` (should print `go1.22.x`)
*   **Docker & Docker Compose**: For local infrastructure (Postgres, MinIO).
    *   Verification: `docker compose version`
*   **Templ CLI**: To compile type-safe components.
    *   Verification: `templ version`
*   **Node.js & NPM**: Required only for compiling Admin CSS and JS bundles.
    *   Verification: `node --version`
*   **PostgreSQL 16 Client**: For manual schema inspections.
    *   Verification: `psql --version` (should show version 16.x)

---

### Environment Variables

| Variable | Required | Default | Example Value | Description |
|----------|----------|---------|---------------|-------------|
| `PORT` | No | `8080` | `8080` | The port the Fiber/Echo server listens on. |
| `DATABASE_URL` | Yes | - | `postgres://user:pass@localhost:5432/vibe_db` | PostgreSQL connection string with JSONB support. |
| `S3_ENDPOINT` | Yes | - | `s3.amazonaws.com` or `localhost:9000` | Endpoint for S3-compatible storage. |
| `S3_BUCKET` | Yes | - | `vibecms-assets` | Name of the bucket for media and backups. |
| `S3_ACCESS_KEY` | Yes | - | `AKIA...` | Access key for S3. |
| `S3_SECRET_KEY` | Yes | - | `secret-string` | Secret key for S3. |
| `RESEND_API_KEY` | No | - | `re_123456789` | API key for Resend.com nested mail delivery. |
| `VIBE_ENV` | No | `production` | `development` | Switches between local asset serving and CDN. |
| `AGENCY_API_KEY` | Yes | - | `uuid-v4-string` | Secret key for the Health Monitoring API. |
| `LICENSE_KEY` | Yes | - | `VIBE-PRO-XXXX` | Domain-bound license key for Pro features. |

---

### Local Development Setup

Follow these steps to initialize a VibeCMS instance on your machine:

1.  **Clone the Repository:**
    `git clone https://github.com/vibe-cms/vibecms.git && cd vibecms`
2.  **Start Local Services:**
    `docker compose -f docker-compose.dev.yml up -d`
    *Outcome:* Postgres (5432) and MinIO (9000) are running.
3.  **Generate Components:**
    `templ generate`
    *Outcome:* Go files are generated for all `.templ` files in `/ui`.
4.  **Install Admin UI Dependencies:**
    `cd ui && npm install && npm run build`
    *Outcome:* `admin.css` and `editor-bundle.js` are created in `ui/assets`.
5.  **Configure Environment:**
    `cp .env.example .env` (ensure values match your local Docker setup).
6.  **Run Migrations and Start:**
    `go run cmd/vibecms/main.go`
    *Outcome:* You should see `Fiber server started on :8080` and `TTFB Monitor: Active`.
7.  **Verify:** Access `http://localhost:8080/admin` and log in with default credentials `admin@vibe.local / admin123`.

---

### CI/CD Pipeline

VibeCMS uses GitHub Actions for automated testing and deployment.

```yaml
name: VibeCMS CI/CD
on:
  push:
    branches: [ main ]
jobs:
  build-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.22'
      - name: Build Admin Assets
        run: |
          cd ui
          npm install
          npm run build
      - name: Generate Templ
        run: go install github.com/a-h/templ/cmd/templ@latest && templ generate
      - name: Run Tests
        run: go test ./... -v
      - name: Docker Build & Push
        run: |
          docker build -t vibe-cms/instance:${{ github.sha }} .
          docker push vibe-cms/instance:${{ github.sha }}
```

---

### Production Deployment

Deploying a new version to a single-site instance:

1.  **Pre-deployment Check:** Verify PostgreSQL backup is current via the Agency API: `GET /api/v1/management/backup-status`.
2.  **Pull New Image:** On the server, run `docker pull vibe-cms/instance:latest`.
3.  **Run Database Migrations:** 
    `docker run --env-file .env vibe-cms/instance:latest ./migrate up`
    *Expected Outcome:* "Migrations successful" log entry.
4.  **Update Container:**
    `docker compose up -d --no-deps vibecms-service`
5.  **Post-deployment Verification:**
    *   Run `curl -I https://yoursite.com` and verify `X-Vibe-TTFB` header is `< 50ms`.
    *   Check `/api/v1/management/health` for "Status: OK".
6.  **Downtime:** Typically < 2 seconds during container restart.

---

### Rollback Procedure

In the event of a failure (e.g., TTFB spikes > 200ms or 500 errors):

1.  **Identify Previous Version:** Find the previous stable Docker image tag (e.g., `v1.0.4`).
2.  **Toggle Image Tag:** Update the `docker-compose.yml` image line to the previous tag.
3.  **Deploy Rollback:**
    `docker compose up -d vibecms-service`
4.  **Database Rollback (If necessary):**
    `docker run --env-file .env vibe-cms/instance:v1.0.4 ./migrate down 1`
5.  **Verification:** Confirm health via the `/admin/dashboard` health widget.
6.  **Cleanup:** Use `docker system prune` only after the site is confirmed stable.