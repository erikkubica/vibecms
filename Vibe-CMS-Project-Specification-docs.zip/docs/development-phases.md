# VibeCMS Development Phases

## About This Document
**Purpose:** A high-level implementation roadmap broken into sequential phases. Each phase defines a deliverable milestone with clear acceptance criteria, dependencies, and scope.
**How AI tools should use this:** Use these phases to understand the build order and scope boundaries; break each phase into granular tasks based on the actual codebase state when starting that phase.
**Consistency requirements:** Phases must reference actual endpoints from api-spec.md, actual tables from database-schema.md, actual components from architecture.md, and actual file paths from folder-structure.md.

This document outlines the step-by-step construction of VibeCMS. We begin with the high-performance Go core and database foundation, moving quickly into the innovative block-based editing system. Following the core content features, we implement the agency-specific monitoring tools, AI integration, and communications layer. The roadmap concludes with production-hardening and deployment strategies, ensuring the sub-50ms performance target is met at every stage of the build.

---

### Phase 1: Foundation, Auth, and Universal Node Core
- **Goal:** Establish the Go Fiber/Echo server, PostgreSQL connection, and the base Universal Node retrieval system.
- **Dependencies:** None. Reference `architecture.md` for Web Layer setup.
- **Scope:** 
    - Project scaffolding and Middlewares (Recovery, Logger).
    - Database schema initialization for `users`, `roles`, `sessions`, and `content_nodes`.
    - Authentication endpoints: `POST /api/v1/auth/login`, `POST /api/v1/auth/logout`, `GET /api/v1/me`.
    - Basic Node CRUD: `GET /api/v1/nodes`, `POST /api/v1/nodes`, `GET /api/v1/nodes/{id}`.
    - RBAC Middleware for Admin/Editor roles.
- **Acceptance Criteria:**
    - User can log in and receive a secure session cookie.
    - A "Universal Node" can be created in the DB and retrieved via UUID.
    - `PublicHandler` can retrieve a node by slug in under 5ms (database time).
- **Out of Scope:** Block rendering and JSON-schema validation.

### Phase 2: High-Performance Rendering & Block Architecture
- **Goal:** Implement the Jet template engine and the "Vibe Loop" for rendering JSONB content.
- **Dependencies:** Phase 1 complete. Reference `product-requirements.md` Section 5.
- **Scope:**
    - `JetEngine` integration and in-memory template caching.
    - Implementation of the `SemaRead` (Schema-on-Read Transformer).
    - Basic block set (Text, Hero) with `themes/{active}/blocks/{type}.jet` structure.
    - `PublicHandler` for sub-50ms TTFB rendering of `content_nodes`.
    - Multi-language routing and `locale_code` resolution.
- **Acceptance Criteria:**
    - Requesting a public slug returns valid HTML generated from `blocks_data`.
    - Changing a block's `version` in JSON triggers the transformation layer without DB updates.
    - Performance benchmark: <50ms TTFB on a "Warm Cache" request.
- **Out of Scope:** The visual Admin UI editor.

### Phase 3: Admin UI and Visual Block Editor
- **Goal:** Build the HTMX/Alpine.js administrative interface for content management.
- **Dependencies:** Phase 2 complete. Reference `architecture.md` Admin Layer.
- **Scope:**
    - Admin Layout using `Templ` and `HTMX`.
    - Dynamic Form Generator based on `blocks/{type}/schema.json`.
    - Node editing: `PATCH /api/v1/nodes/{id}`.
    - Drag-and-drop reordering: `PATCH /admin/nodes/reorder`.
    - Side-by-side translation UI for multi-language support.
- **Acceptance Criteria:**
    - Editor can drag blocks to reorder them with immediate persistence via HTMX.
    - Form fields dynamically appear/disappear based on the block's JSON schema.
    - User can switch languages in the Admin UI without a full page refresh.
- **Out of Scope:** AI generation and Media Management.

### Phase 4: Media Manager & S3 Optimization Pipeline
- **Goal:** Implement stateless media handling and the asynchronous WebP processing pool.
- **Dependencies:** Phase 1 complete. Reference `database-schema.md` Section 5.
- **Scope:**
    - S3-compatible SDK integration (MinIO for local, R2/S3 for prod).
    - `media_assets` table and `POST /api/v1/media/upload`.
    - `MediaProcessor` service using `libvips` for WebP conversion.
    - Admin Media Gallery: `GET /api/v1/media`, `DELETE /api/v1/media/{id}`.
    - Custom Jet function `vibe_media()` for URL resolution.
- **Acceptance Criteria:**
    - Uploaded JPEGs are automatically converted to WebP and stored in S3.
    - Gallery supports infinite scroll via HTMX `hx-trigger="revealed"`.
    - Binary does not store any files locally; `vibe://media/` URIs resolve correctly in templates.
- **Out of Scope:** AI-generated alt text.

### Phase 5: Tengo Scripting & Communication Layer
- **Goal:** Enable zero-rebuild extensibility and the asynchronous email dispatch system.
- **Dependencies:** Phase 2 and 3 complete. Reference `product-requirements.md` Section 4.
- **Scope:**
    - `TengoVM` implementation with the `vibe` global object.
    - File watcher for `/themes/{name}/scripts/`.
    - `email_logs` table and `MailWorker` for SMTP/Resend.
    - `GET /api/v1/management/email-logs` for audit.
    - Form Submission Hook: `POST /api/vibe/form/{id}` handled by `.tgo` scripts.
- **Acceptance Criteria:**
    - A `.tgo` script can fetch external data and inject it into a Jet template.
    - Form submissions trigger emails that are logged as `pending` then `sent` in the database.
    - Script execution is killed if it exceeds the 15ms safety deadline.
- **Out of Scope:** Advanced Cron scheduling.

### Phase 6: AI Integration & Advanced SEO
- **Goal:** Add AI-native metadata generation and automated SEO tooling.
- **Dependencies:** Phase 3 and 4 complete. Reference `api-spec.md` Section 4.4.
- **Scope:**
    - LLM provider integration (OpenAI/Anthropic).
    - SEO Suggestion endpoints: `POST /admin/api/ai/suggest-seo/{node_id}` and `POST /admin/api/ai/suggest-block`.
    - Automated Sitemap.xml generation (in-memory) and `robots.txt` handler.
    - Schema.org JSON-LD generation engine.
    - `Ahrefs/Semrush` API metric display in Admin.
- **Acceptance Criteria:**
    - Real-time sitemap is served in <10ms from memory.
    - "AI Suggest" button populates SEO title/desc without overwriting manual data.
    - JSON-LD blocks appear in the page `<head>` based on the `blocks_data` content.
- **Out of Scope:** Database backups.

### Phase 7: Agency Monitoring & Task Scheduler
- **Goal:** Build the high-resolution telemetry and internal cron system for fleet management.
- **Dependencies:** Phase 5 complete. Reference `api-spec.md` Section 4.
- **Scope:**
    - `Cron` scheduler service and `system_tasks` persistence.
    - Database backup task: `POST /api/v1/management/backups` (S3 streaming).
    - Agency Health API: `GET /api/v1/management/health`.
    - License Enforcement Middleware and 24-hour verification task.
    - Snapshotting of `system_health_snapshots`.
- **Acceptance Criteria:**
    - External dashboard can query site health/TTFB metrics via API Key.
    - DB backups are streamed directly to S3 without bloating local disk.
    - System enters "Core Mode" if the license signature fails verification.
- **Out of Scope:** Final CI/CD runners.

### Phase 8: Hardening, CI/CD, and Production Launch
- **Goal:** Final performance tuning, security audits, and automated deployment pipelines.
- **Dependencies:** All prior phases.
- **Scope:**
    - Final TTFB benchmarks and GORM/pgx query optimization.
    - Implementation of the `system_audit_log` for all admin actions.
    - GitHub Actions for binary builds and MinIO-based integration tests.
    - Production `config.yaml` hardening (TLS 1.3, CSP headers).
    - Documentation for Agency "push-button" updates.
- **Acceptance Criteria:**
    - System passes 5,000 requests/sec load test with <50ms p95 TTFB.
    - Automated tests confirm zero local file persistence.
    - License key correctly locks Pro-features on a clean domain installation.
- **Out of Scope:** Future feature versions.