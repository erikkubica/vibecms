# VibeCMS Folder Structure

## About This Document

**Purpose:** Directory layout and naming conventions. Establishes where every type of file belongs in the project.

**How AI tools should use this:** Create new files only in directories consistent with this layout; use the naming conventions specified here.

**Consistency requirements:** Directory structure must reflect framework conventions from tech-stack.md and component boundaries from architecture.md.

VibeCMS is organized as a modular Go application designed for high performance and portability. The structure separates the core CMS engine from the customizable theme layer to support "Zero-Rebuild Extensibility." The project follows standard Go project layouts (standard-layout) while accommodating specific directories for the Jet template engine and Tengo scripting files.

---

## Directory Tree

```text
.
├── cmd/                          # Application entry points [hand-written]
│   └── vibecms/                  
│       └── main.go               # Main application bootstrap
├── internal/                     # Private application code [hand-written]
│   ├── api/                      # Agency-focused Health & Management APIs
│   │   ├── agency_handler.go     # example
│   │   └── health_check.go       # example
│   ├── auth/                     # RBAC and session management logic
│   │   ├── middleware.go         # example
│   │   └── session_store.go      # example
│   ├── cms/                      # Core "Vibe Loop" rendering & node logic
│   │   ├── node_service.go       # example
│   │   ├── renderer.go           # example
│   │   └── schema_transformer.go # example
│   ├── cron/                     # Internal task scheduler and workers
│   │   ├── backup_job.go         # example
│   │   ├── mail_dispatcher.go    # example
│   │   └── scheduler.go          # example
│   ├── db/                       # Database connection and GORM models
│   │   ├── migrations/           # SQL migration files [generated/hand-written]
│   │   ├── models/               # Struct definitions for Postgres/JSONB
│   │   │   ├── content_node.go   # example
│   │   │   └── media_asset.go    # example
│   │   └── postgres.go           # example
│   ├── integrations/             # Third-party API clients
│   │   ├── resend_client.go      # example
│   │   ├── s3_storage.go         # example
│   │   └── seo_api.go            # example
│   └── media/                    # libvips image processing logic
│       └── processor.go          # example
├── pkg/                          # Publicly shareable Go libraries [hand-written]
│   └── tengo_ext/                # Custom Tengo modules/extensions
│       └── vibe_module.go        # example
├── ui/                           # Admin Interface (HTMX/Alpine/Templ) [hand-written]
│   ├── assets/                   # Static compiled JS/CSS
│   │   ├── admin.css             # example
│   │   └── editor-bundle.js      # example
│   ├── components/               # Reusable Templ components
│   │   ├── BlockEditor.templ     # example
│   │   └── MediaSelector.templ   # example
│   └── layouts/                  # Admin base layouts
│       └── AdminLayout.templ     # example
├── themes/                       # Customer-facing theme files [hand-written]
│   └── [theme-name]/             
│       ├── assets/               # Frontend CSS/JS
│       ├── blocks/               # Individual block Jet templates
│       │   ├── hero_section.jet  # example
│       │   └── text_block.jet    # example
│       ├── layouts/              # Master page Jet templates
│       │   └── main.jet          # example
│       ├── scripts/              # Tengo (.tgo) extensibility scripts
│       │   └── pre_render.tgo    # example
│       └── theme.json            # Theme metadata and block definitions
├── storage/                      # Local data persistence (Dev only) [generated]
│   ├── backups/                  # Local temp backup zips
│   └── logs/                     # System and mail logs
├── configs/                      # Default configuration files [hand-written]
│   ├── config.yaml               # example
│   └── license.sample.json       # example
├── bin/                          # Compiled binary output [generated]
└── scripts/                      # Deployment and build scripts [hand-written]
    └── build_admin.sh            # example
```

---

## File Naming Conventions

| File Type | Convention | Example |
| :--- | :--- | :--- |
| **Go Source** | snake_case | `content_renderer.go` |
| **Templ Components** | PascalCase | `BlockEditor.templ` |
| **Jet Templates** | snake_case | `contact_form.jet` |
| **Tengo Scripts** | snake_case | `before_render.tgo` |
| **CSS/JS Assets** | kebab-case | `admin-styles.css` |
| **JSON Schemas** | kebab-case | `hero-block.schema.json` |
| **Migrations** | timestamp_prefix | `202405201015_create_nodes.sql` |

---

## Key Files

| File | Purpose |
| :--- | :--- |
| `cmd/vibecms/main.go` | The main entry point that initializes the Fiber/Echo server and connects components. |
| `internal/cms/renderer.go` | The core "Vibe Loop" engine that fetches JSONB data and coordinates Jet rendering. |
| `internal/cms/schema_transformer.go` | Handles "Schema-on-Read" logic to transform old block data to the current version. |
| `pkg/tengo_ext/vibe_module.go` | Defines the API and sandboxed objects available to `.tgo` scripts. |
| `ui/components/BlockEditor.templ` | The primary type-safe component for the drag-and-drop JSON editor interface. |
| `internal/cron/scheduler.go` | Manages the internal Go-routine pool for backups, SEO analysis, and mail. |
| `themes/default/theme.json` | Configuration file defining what blocks and scripts the current theme supports. |
| `internal/db/models/content_node.go` | The central GORM model for the `content_nodes` table including JSONB fields. |

---

## Module Organization
- **Separation of Logic:** The `internal/cms` module must contain no third-party API logic (e.g., Resend); all external calls are routed through `internal/integrations`.
- **Theme Isolation:** Public-facing HTML and logic reside entirely in `/themes`. The core binary serves these but does not depend on specific theme keys.
- **Admin UI:** All administrative interfaces use `Templ` for type-safety, which are then called by handlers in `internal/api` or `internal/cms`.
- **Background Tasks:** All long-running or resource-intensive logic must be triggered via `internal/cron` to protect the primary request loop's 50ms TTFB.