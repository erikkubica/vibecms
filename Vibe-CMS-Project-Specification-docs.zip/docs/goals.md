# VibeCMS Goals and Success Metrics

## About This Document

**Purpose:** Defines measurable success criteria. Features and implementation choices in other documents should be evaluated against these goals.

**How AI tools should use this:** Reference these goals when prioritizing features; suggest only work that advances at least one goal.

**Consistency requirements:** Stay aligned with overview.md (product scope); every goal should map to at least one requirement in product-requirements.md.

VibeCMS is built to solve the performance and maintenance challenges faced by modern agencies. This document outlines the specific, quantitative targets we must hit to consider the project a success. These metrics focus on extreme technical performance, agency operational efficiency, and the "AI-native" promise of the platform.

---

### Stated Goals

**[P0] Sub-50ms Time to First Byte (TTFB) — < 50ms**
- Baseline: N/A (new product)
- Target: < 50ms for cached routes and < 80ms for uncached JSONB-to-Jet rendering at P95.
- Measurement method: Server-side instrumentation via Fiber/Echo middleware and external synthetic monitoring (e.g., Checkly or Pingdom).
- Timeline: By launch.
- Rationale: This is the core value proposition of VibeCMS to eliminate "WordPress bloat" and ensure superior SEO and user experience.

**[P0] Zero-Rebuild Logic Execution — 100% success rate**
- Baseline: N/A (new product)
- Target: 100% of custom business logic (forms, API proxying) executed via Tengo without requiring a binary re-compilation.
- Measurement method: Automated test suite verifying `.tgo` script execution hooks in the rendering pipeline.
- Timeline: By launch.
- Rationale: Agencies need to iterate on client-specific logic without managing complex CI/CD pipelines for every minor change.

**[P1] AI-Compatible Content Structure — < 1% Schema Validation Errors**
- Baseline: N/A (new product)
- Target: Less than 1% of AI-generated content blocks fail JSON-schema validation upon insertion.
- Measurement method: Application logs tracking validation failures during AI-suggestion "Apply" actions.
- Timeline: Within 30 days of v1.0 launch.
- Rationale: To be truly "AI-Native," the system must provide a predictable, schema-first interface that LLMs can write to reliably.

**[P1] Real-time SEO Readiness — 100/100 Lighthouse SEO Score**
- Baseline: N/A (new product)
- Target: 100/100 score on Google Lighthouse SEO audits for default theme installations.
- Measurement method: Google Lighthouse CI in the deployment pipeline.
- Timeline: By launch.
- Rationale: High-performance technical SEO is a stated requirement for the SEO Specialist user Persona.

---

### Architected Goals

**[P0] Asset Optimization Efficiency — 100% WebP Adoption**
- Baseline: N/A (new product)
- Target: 100% of JPEG/PNG uploads converted to WebP format automatically.
- Measurement method: Media Manager database audit of `mime_type` and `extension` fields.
- Timeline: By launch.
- Rationale: Because the 50ms TTFB target requires lean payloads, automated image optimization is critical to prevent unoptimized assets from negating server-side speed.

**[P1] Agency Monitoring Reliability — 99.9% API Availability**
- Baseline: N/A (new product)
- Target: 99.9% uptime for the secure Health Monitoring API endpoint on each instance.
- Measurement method: External uptime monitoring of the `/api/v1/health` endpoint.
- Timeline: Within 30 days of v1.0 launch.
- Rationale: Because agencies manage hundreds of sites, the centralized monitoring API must be rock-solid to provide accurate fleet status.

**[P1] Email Deliverability Visibility — 100% Log Coverage**
- Baseline: N/A (new product)
- Target: 100% of outgoing messages via SMTP/Resend captured in the internal DB log with provider response codes.
- Measurement method: SQL audit comparing `mail_logs` count against successful provider API calls.
- Timeline: By launch.
- Rationale: To reduce agency support overhead, developers must be able to prove email delivery status without checking external logs.

**[P2] Data Portability — < 10 second Backup Completion**
- Baseline: N/A (new product)
- Target: Full DB and asset metadata backup to S3-compatible storage in under 10 seconds for sites under 1GB.
- Measurement method: Internal Cron task execution logs.
- Timeline: Planned for future release (v1.1).
- Rationale: Fast, non-blocking backups are necessary to ensure the site remains responsive during scheduled maintenance tasks.

---

### Anti-Goals

*   **Native Multi-Tenant Hosting:** It is NOT a goal to host multiple domains/sites from a single Go process. This ensures maximum isolation and avoids the performance degradation inherent in shared-resource environments.
*   **WASM Scripting Support (MVP):** While high performance, WASM is explicitly deprioritized for the initial release to focus on the developer ergonomics of the Tengo scripting engine.
*   **Legacy Browser Support (IE11):** Because the Admin UI relies on modern standards like HTMX and Alpine.js, supporting legacy browsers is deprioritized to keep the codebase lean and high-performing.
*   **Built-in E-commerce Checkout:** VibeCMS is a content and SEO-focused engine; full PCI-compliant checkout logic is outside the current scope to prevent feature creep.