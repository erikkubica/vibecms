# VibeCMS Observability Strategy

## About This Document

**Purpose:** Metrics, logging, tracing, and alerting strategy so the team can understand system health and diagnose issues in production.

**How AI tools should use this:** Instrument new code with the logging patterns and metric names defined here; do not introduce new logging formats or metric namespaces that conflict with this document.

**Consistency requirements:** Service names and component boundaries must match architecture.md; SLO targets should derive from the performance goals in goals.md; log fields should reference the data model from database-schema.md where relevant.

VibeCMS is built on a "performance-first" philosophy where every millisecond counts. To maintain our sub-50ms TTFB target, observability must be lightweight and non-blocking. This document defines how we monitor the Go binary, the integrity of our JSONB content structures, the execution of Tengo scripts, and the health of background tasks. By following these standards, we ensure that agencies managing hundreds of sites have immediate visibility into which instances are performing optimally and which require intervention.

---

### Service Level Objectives (SLOs)

| SLO | Target | Measurement Window | Error Budget |
|-----|--------|--------------------|-------------|
| Public Page P95 TTFB | < 50ms | 30 days | 0.5% of requests may exceed |
| API Availability | > 99.9% | 30 days | ~43 mins of downtime |
| Image Optimization Latency | < 5s (P90) | 7 days | 1% of uploads may exceed |
| Backup Success Rate | 100% | 30 days | 0 failures allowed |
| Tengo Hook Duration | < 15ms | 30 days | 0.1% of hook executions |

---

### Structured Logging

**Log Format:** JSON (Standardized via `slog` or `zerolog`)

**Required Fields:**
- `timestamp`: RFC3339Nano
- `level`: DEBUG/INFO/WARN/ERROR/FATAL
- `service`: `vibecms-core`
- `request_id`: ULID (from `X-Vibe-Request-ID`)
- `node_id`: UUID (if context is a content node)
- `user_id`: UUID (if authenticated admin)
- `duration_ms`: Execution time for the logged event

**Log Levels & Examples:**
- **DEBUG:** `slog.Debug("tengo_vm_state", "instructions", 450, "mem_kb", 1024)` - Deep VM inspection.
- **INFO:** `slog.Info("request_completed", "path", "/about", "ttfb_ms", 32)` - Standard audit.
- **WARN:** `slog.Warn("license_near_expiry", "days_left", 3)` - Non-critical system state.
- **ERROR:** `slog.Error("db_query_failed", "error", err, "query_type", "jsonb_fetch")` - Operation failed.
- **FATAL:** `slog.Log(LevelFatal, "panic_recovered", "stack", stack_trace)` - System crash/exit.

**Events that MUST be logged:**
- **Request Lifecycle:** Method, Path, Status, Duration, Cache-Status.
- **External Calls:** S3 uploads, Resend API status, Ahrefs/Semrush sync results.
- **Database:** Query duration for JSONB fetches (log if > 10ms).
- **Security:** Brute force triggers (log user email, IP), License verification failures.
- **Background:** Backup start/end, Cron task completion with exit code.

**SENSITIVE FIELDS (NEVER LOG):**
- `password_hash`, `mfa_secret`, `session_token`, `api_key` (Resend/S3), `X-Vibe-Agency-Key`.

---

### Application Metrics

| Metric Name | Type | Labels | Description |
|-------------|------|--------|-------------|
| `vibe_http_requests_total` | Counter | method, path, status, cache_status | Total requests processed |
| `vibe_httfb_seconds` | Histogram | path, locale | Time to First Byte latency |
| `vibe_db_query_duration_seconds` | Histogram | query_type, table | PostgreSQL query performance |
| `vibe_tengo_execution_seconds` | Histogram | script_path, outcome | Tengo VM execution time |
| `vibe_media_upload_bytes` | Counter | mime_type | Volume of raw media ingested |
| `vibe_media_processing_seconds`| Histogram | original_format | Image optimization duration |
| `vibe_backup_size_bytes` | Gauge | storage_provider | Physical size of last database dump |
| `vibe_memory_usage_bytes` | Gauge | - | Active heap allocation (Target < 64MB) |
| `vibe_active_goroutines` | Gauge | - | Concurrency level |
| `vibe_license_status` | Gauge | - | 1 for Valid, 0 for Restricted/Grace |

---

### Distributed Tracing

As a single-binary application, distributed tracing follows the **W3C TraceContext** standard for external calls, but internally focuses on **Request ID Propagation**.

- **Propagation:** Every request generates a ULID stored in the Fiber/Echo context as `req_id`.
- **Span Creation:** Spans must be created for:
    1. `vibe.render`: Total Jet template rendering.
    2. `vibe.tengo`: VM execution.
    3. `vibe.db`: SQL execution via `pgx`.
    4. `vibe.s3`: Multipart upload/download segments.
- **Attributes:** Every span must include `node_id` and `tenant_domain` (if applicable).

---

### Dashboards

**1. Public Site Health — SRE Dashboard**
- **Panels:** P95/P99 TTFB (Line chart), HTTP Status 5xx vs 2xx (Ratio), Cache Hit Rate (Gauge), Request Volume per Locale.
- **Query Example:** `histogram_quantile(0.95, sum(rate(vibe_httfb_seconds_bucket[5m])) by (le))`
- **Refresh:** 30 seconds.

**2. Agency Fleet Management — Account Manager Dashboard**
- **Panels:** License Status across instances, Backup Success Rate (Last 24h), Storage Usage (S3 Bucket Growth), Pending Updates count.
- **Refresh:** 5 minutes.

**3. Background Worker Performance — Developer Dashboard**
- **Panels:** Media processing queue depth, Cron task success/failure grid, Memory usage vs 64MB limit, Tengo script error frequency.
- **Refresh:** 1 minute.

---

### Alerting Rules

| Alert Name | Condition | Severity | Response |
|------------|-----------|----------|----------|
| **HighTTFB** | `vibe_httfb_seconds > 0.05` for 3m | P1 | Inspect Postgres locks or slow Tengo scripts. |
| **ErrorRateSpike** | `rate(vibe_http_requests_total{status=~"5.."}[1m]) > 2%` | P0 | Check DB connectivity and logs for panics. |
| **MemoryExhaustion** | `vibe_memory_usage_bytes > 60MB` | P1 | Force GC or investigate memory leak in Tengo VM. |
| **BackupFailed** | `vibe_task_logs{task="backup", status="failed"} > 0` | P0 | Manually trigger backup and check S3 permissions. |
| **LicenseGrace** | `vibe_license_status == 0` | P2 | Contact client for payment/renewal. |
| **S3Connectivity** | `vibe_infrastructure_status{provider="s3"} == 0` | P0 | Verify R2/S3 service status and credentials. |

**On-Call Routing:** P0 alerts trigger PagerDuty/Opsgenie notifications. P1 and P2 alerts are dispatched via Resend to the Agency-Manager email configured in `system_settings`.