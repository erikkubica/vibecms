# VibeCMS Product Overview

VibeCMS is a high-performance, Go-based Content Management System engineered specifically for agencies and developers who prioritize speed, AI-compatibility, and maintainability. In a market saturated with "bloated" CMS solutions that often exceed two-second response times for basic requests, VibeCMS sets a rigorous performance benchmark with a sub-50ms Time to First Byte (TTFB) target. 

The system leverages a modern, "AI-native" architecture where every content block is defined by a strict JSON schema. This ensures that the system is not only human-readable but programmatically accessible for AI-driven development and content generation. By utilizing a "zero-rebuild" extensibility model via the Tengo scripting engine, developers can inject custom business logic without the need for Go recompilation, offering a middle ground between the safety of a compiled backend and the flexibility of interpreted scripts.

## About This Document

**Purpose:** This document anchors the entire bundle by defining product scope, target users, and problem statement. All other bundle documents derive their boundaries from this.

**How AI tools should use this:** Read this document first; use the product scope to constrain feature suggestions; reject code changes outside the described scope.

**Consistency requirements:** All other bundle documents (goals.md, product-requirements.md, tech-stack.md, architecture.md, database-schema.md, api-spec.md, folder-structure.md, development-phases.md) must stay within the product boundaries defined here.

### Problem Statement

VibeCMS addresses several critical pain points found in modern web development and agency workflows:

1.  **"WordPress Bloat" and Performance Degradation (STATED):** Standard CMS platforms often require 1-2 seconds just to respond to a request due to heavy plugin overhead and inefficient database queries. Currently, users deal with this by implementing complex caching layers (Varnish, Redis) or CDNs, which adds architectural complexity and fails to solve the root issue of a slow origin server.
2.  **Lack of AI-Friendly Data Structures (STATED):** Traditional CMS content is often trapped in inconsistent HTML blobs or opaque database formats. Because the user requires an "AI-native" workflow, the system will also need a strict JSON-schema approach—this allows LLMs to accurately generate or modify content blocks without breaking the UI.
3.  **The "Rebuild Friction" for Custom Logic (STATED):** In Go-based systems, adding custom logic usually requires a full binary re-compilation and deployment. This is insufficient for agencies needing to iterate quickly on client requests. VibeCMS solves this by using Tengo scripting to allow real-time logic updates without server restarts.
4.  **Agency Management Overhead (ARCHITECTED):** Agencies managing hundreds of independent sites often lose visibility into which instances are failing or outdated. Because the user explicitly mentioned managing "hundreds of sites" with 1:1 deployments, a centralized health monitoring API is necessary to prevent manual, site-by-site status checks.
5.  **Media Performance Bottlenecks (ARCHITECTED):** High-performance sites are frequently slowed down by unoptimized images. Because the 50ms TTFB target requires lean payloads, the system must automate WebP conversion—manual optimization by editors is inconsistent and prone to human error.

### Target Users

*   **The Agency Developer (STATED):**
    *   **Role:** Technical lead at a digital agency.
    *   **Goal:** Deploy high-performance websites quickly and maintain them across various clients.
    *   **Frustrations:** Dealing with security patches in PHP-based systems and the slow development cycle of compiled languages.
    *   **How VibeCMS helps:** Provides a high-speed Go backend with the flexibility of a scripting layer and an AI-ready block editor.
*   **The SEO Specialist (STATED):**
    *   **Role:** Responsible for organic search rankings.
    *   **Goal:** Ensure technical SEO is perfect (Schema.org, Sitemaps, Core Web Vitals).
    *   **Frustrations:** Inflexible CMS platforms that require plugins to manage basic meta-tags or sitemaps.
    *   **How VibeCMS helps:** Offers native, real-time Schema.org generation and AI-assisted metadata suggestions directly in the workflow.
*   **The Content Editor (ARCHITECTED):**
    *   **Role:** Non-technical user managing day-to-day site updates.
    *   **Goal:** Create visually consistent pages without touching code.
    *   **Frustrations:** "Empty canvas" editors that are too complex or rigid editors that don't allow creative layouts.
    *   **How VibeCMS helps:** Detailed JSON-based block editor gives them a "lego-like" experience that remains within the design constraints defined by the developer.

### Core Workflows

#### 1. The "Vibe Loop" (Public Rendering)
*   **Context:** A visitor navigates to a URL on a VibeCMS-powered site.
*   **Flow:**
    1.  The Fiber/Echo server matches the URL slug against the `content_nodes` table.
    2.  The system identifies the active theme and language context.
    3.  JSONB data for the page blocks is retrieved from PostgreSQL.
    4.  The `pre_render.tgo` Tengo script executes to handle any custom dynamic logic (e.g., fetching a price from an external API).
    5.  The Jet engine iterates through the JSON data, matching JSON types to `.jet` template files.
    6.  The final HTML is streamed to the visitor.
*   **Outcome:** The visitor sees the page in under 50ms TTFB.

#### 2. AI-Assisted Block Creation
*   **Context:** A developer or editor is building a new landing page in the Admin UI.
*   **Flow:**
    1.  The user selects "Add Block" and chooses a type (e.g., "Feature Grid").
    2.  The user clicks "AI Suggest" for content.
    3.  The system sends the block’s JSON schema to an LLM.
    4.  The LLM returns data perfectly formatted to fit the schema.
    5.  The Admin UI (HTMX) updates the block fields with the suggestions.
*   **Outcome:** Structured content is generated without manual typing or formatting errors.

#### 3. Zero-Rebuild Logic Update
*   **Context:** An agency needs to add a custom lead-capture form that sends data to a specific third-party CRM.
*   **Flow:**
    1.  The developer creates a `contact_form.tgo` script in the theme folder.
    2.  The developer defines the CRM API endpoint and mapping within the script.
    3.  The developer uploads the script via the Admin UI or Git.
    4.  The next form submission triggers the script hook automatically.
*   **Outcome:** New business logic is live without a server restart or binary deployment.

### Out of Scope

*   **Native Multi-site support within one deployment (STATED):** To ensure performance and isolation (1:1 site-to-binary ratio), multi-tenancy inside a single database instance is excluded.
*   **Direct SQL access from Scripting Layer (ARCHITECTED):** Because the system needs to maintain stability and security, Tengo scripts will interact with a restricted API rather than raw SQL.
*   **Legacy Image Support (ARCHITECTED):** To maintain the 50ms TTFB goal, the system will not support serving unoptimized, high-resolution original images to public users; all images are processed through the Media Manager.
*   **Complex WASM Integrations (STATED):** While WASM was identified as an interest, it is deferred from the MVP to focus on stabilizing the Tengo scripting implementation.
*   **Built-in E-commerce Engine (ARCHITECTED):** Full cart/checkout/inventory management is out of scope for the initial version to prevent feature bloat; the focus is on a high-performance Content Management and SEO.