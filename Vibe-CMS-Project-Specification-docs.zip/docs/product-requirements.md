## Section 1: Performance Targets and Sub-50ms TTFB Architecture

VibeCMS is engineered with a "Performance-First" philosophy, where the 50ms Time to First Byte (TTFB) target is not merely a goal but a hard architectural constraint. To achieve this in a dynamic, database-driven CMS environment, VibeCMS utilizes a multi-layered optimization strategy that minimizes CPU cycles and I/O wait times at every stage of the request-response lifecycle.

### 1.1 The Fifty-Millisecond Constraint
In modern web performance, TTFB is the primary indicator of server efficiency. Traditional PHP-based CMS platforms often struggle with overhead from session management, heavy ORM abstraction layers, and synchronous plugin execution, leading to typical TTFB values of 200ms to 2s. VibeCMS targets <50ms by leveraging Go’s concurrency model and a "lean path" execution strategy.

#### Performance Benchmarks (Target)
| Metric | Target Value | Condition |
| :--- | :--- | :--- |
| **TTFB (Cold Cache)** | < 80ms | First request after restart, DB hit required. |
| **TTFB (Warm Cache)** | < 30ms | Metadata and Route in-memory, DB hit for JSONB. |
| **TTFB (Fully Cached)** | < 12ms | Entire node HTML fragment in-memory. |
| **Memory Footprint** | < 64MB | Idle state with basic theme. |
| **Concurrent Req/Sec** | > 5,000 | Measured on 2-core / 4GB RAM instance. |

### 1.2 The "Low-Alloc" Request Pipeline
The core request handler (built on **Fiber** or **Echo**) is designed to minimize heap allocations. This is achieved through:
*   **Struct Pooling:** Reusing internal context objects to reduce Garbage Collection (GC) pressure.
*   **Zero-Copy Routing:** Using a Radix-tree based router that avoids string concatenations during path matching.
*   **Static Route Pre-computation:** All standard routes (Admin, API, Assets) are registered at init, while content slugs are managed via a high-speed lookup table.

### 1.3 Schema-on-Read & JSONB Optimization
PostgreSQL's `JSONB` is central to the performance strategy. By utilizing a **Schema-on-Read** approach with a Transformation Layer, VibeCMS avoids complex table joins that typically slow down traditional CMS platforms.

*   **Single-Row Fulfillment:** For a standard page render, the system executes exactly *one* primary SQL query: `SELECT blocks_data, metadata FROM content_nodes WHERE slug = $1 LIMIT 1`.
*   **JSONB Inclusion:** Instead of joining "Block" tables, the entire page structure is stored in the `blocks_data` column.
*   **Version Mapping:** The Transformation Layer intercepts the JSONB data. If the `schema_version` in the JSON does not match the current theme's expectations, the Go backend performs an in-memory transformation (e.g., renaming keys or setting defaults) before passing it to the Jet engine. This prevents the need for blocking `ALTER TABLE` operations or background data migrations that could spike I/O.

### 1.4 High-Speed Template Rendering (Jet Engine)
VibeCMS utilizes the **Jet** templating engine for its public-facing views. Jet compiles templates into Go bytecode, making it significantly faster than standard `html/template`.

*   **Pre-Compilation:** All `.jet` files in the `{theme}/layouts` and `{theme}/blocks` directories are compiled into memory at startup.
*   **Dependency Tracking:** The engine maintains a map of block dependencies. When a user requests a page, the "Vibe Loop" iterates through the JSONB blocks and executes the pre-compiled bytecode for each block type.
*   **Context Injection:** A minimal `vibe` global object is injected into the Jet context, providing access to localized strings and SEO metadata without re-fetching from the database.

### 1.5 In-Memory Strategic Caching
To bypass the database entirely for high-traffic nodes, VibeCMS implements a two-tier caching strategy:

1.  **Sitemap & Route Cache (L1):** The mapping of `slug -> node_id` is stored in a thread-safe `map[string]uuid.UUID` in-memory. This eliminates the "Route Discovery" DB hit.
2.  **Metadata Cache (L2):** SEO tags, robots settings, and Schema.org snippets are stored in-memory. Since these are high-impact for crawlers and rarely change, serving them from memory ensures that search engine bots perceive the site as instantaneous.
3.  **Fragment Cache (Optional):** Expensive blocks (e.g., a "Most Recent Posts" block with complex filtering) can be cached as raw HTML fragments in-memory, keyed by a hash of their configuration JSON.

### 1.6 Scripting Performance (Tengo VM)
Extensibility through **Tengo** (`.tgo`) is optimized to prevent it from becoming a bottleneck:
*   **Pre-Compiled Scripts:** Scripts are compiled to bytecode once when the file is modified or at startup. 
*   **Instruction Limits:** To prevent runaway scripts (loops) from hanging the request, the Tengo VM is initialized with a maximum instruction count per execution.
*   **Shared Globals:** The `vibe` global object is passed by reference, ensuring no expensive data copying occurs between the Go environment and the Tengo VM.

### 1.7 Sidecar Architecture for Heavy Tasks
To preserve the 50ms TTFB for end-users, heavy computational or I/O tasks are offloaded to an **Internal Cron sidecar process**.
*   **Asynchronous Processing:** Operations like Image WebP optimization, S3 backups via `pg_dump --no-lock`, and AI-generated SEO suggestions are queued and handled by a background worker.
*   **Resource Throttling:** The sidecar is limited to a lower CPU priority than the Fiber/Echo web server, ensuring that a backup process never starves a public request of cycles.
*   **Non-Blocking Mail:** Sending emails via SMTP or Resend is strictly asynchronous. The request handler logs the intent to the `email_logs` table and returns the response to the user immediately; the sidecar handles the actual network handshake with the provider.

### 1.8 Architectural Constraints for Performance
To maintain these targets, the following constraints are strictly enforced:
1.  **No Middleware Bloat:** Global middleware is restricted to Logging, Recovery, and Security (RBAC/License). Dynamic feature detection is handled at the Block/Script level.
2.  **Stateless Execution:** The primary binary does not write to the local file system during a request (excluding logs). All persistence is directed to PostgreSQL or S3.
3.  **Small Binary Size:** By avoiding heavy dependencies and focusing on the Go Standard Library + Fiber/Echo, the binary remains small, facilitating fast cold starts in containerized environments.

## Section 2: Content Modeling and Universal Node Structure

VibeCMS employs a "Universal Node" architecture designed to unify disparate content types (Pages, Blog Posts, Custom Entities) into a single, high-performance retrieval model. By leveraging PostgreSQL's `JSONB` capabilities and a strict Schema-on-Read strategy, the system achieves the flexibility of a NoSQL document store while maintaining the relational integrity and ACID compliance required for enterprise-grade agency deployments.

### 2.1 The `content_nodes` Table Definition

The primary storage vehicle for all content is the `content_nodes` table. Every routable entity in VibeCMS is a "Node." This design eliminates the need for complex joins across multiple tables (e.g., `wp_posts` vs `wp_postmeta`), which is a critical factor in hitting the 50ms TTFB target.

| Column | Type | Description |
| :--- | :--- | :--- |
| `id` | `UUID` | Primary Key (ULID-compatible for sorted insertion). |
| `slug` | `VARCHAR(255)` | Indexed URL segment (e.g., "about-us"). |
| `parent_id` | `UUID` | Self-referencing FK for hierarchical structures (Pages). |
| `node_type` | `VARCHAR(50)` | Discriminator: `page`, `post`, or custom (e.g., `property`). |
| `status` | `VARCHAR(20)` | `draft`, `published`, `archived`, `scheduled`. |
| `language_code` | `VARCHAR(5)` | ISO code (e.g., `en`, `sk`). Part of a composite unique index with `slug`. |
| `blocks_data` | `JSONB` | The core payload: An array of block objects and their values. |
| `metadata` | `JSONB` | SEO tags, OpenGraph data, and AI-generated suggestions. |
| `schema_version` | `INT` | Used for the Schema-on-Read transformation layer. |
| `author_id` | `UUID` | Reference to the `users` table. |
| `published_at` | `TIMESTAMPTZ`| Nullable; used for scheduled publishing. |
| `created_at` | `TIMESTAMPTZ`| Auto-generated timestamp. |
| `updated_at` | `TIMESTAMPTZ`| Updated on every save for versioning triggers. |

**Indexing Strategy:**
*   `CREATE INDEX idx_nodes_lookup ON content_nodes (slug, language_code, status);`
*   `CREATE INDEX idx_nodes_gin_blocks ON content_nodes USING GIN (blocks_data);` (Allows for high-speed querying inside JSON content).

### 2.2 Universal Node Logic & Type Discriminators

While all nodes reside in one table, their behavior is governed by the `node_type`. This allows agencies to define "Custom Post Types" without creating new database tables.

1.  **Pages:** Hierarchical nodes where the full URL path is reconstructed from `parent_id` recursion.
2.  **Posts/Articles:** Flat nodes often grouped by categories/tags (stored in a separate `taxonomy_nodes` table).
3.  **Custom Entities:** Defined via a `content_types.json` configuration file or the Admin UI. For example, a "Team Member" entity might disable the standard "Content Editor" and only allow specific fields like `position`, `linkedin_url`, and `bio_photo`.

### 2.3 `blocks_data` Structure (AI-Native Design)

The `blocks_data` field is an ordered JSON array. Each element in the array follows a strict internal schema that is optimized for both the Jet/Templ rendering engine and LLM readability.

```json
[
  {
    "id": "blk_01H2X...",
    "type": "hero_section",
    "version": 1,
    "values": {
      "title": "Experience the Vibe",
      "subtitle": "High-performance CMS for the modern web.",
      "cta_link": "/contact",
      "background_image": "vibe://media/hero-bg.webp"
    },
    "settings": {
      "padding_top": "large",
      "theme_variant": "dark"
    }
  },
  {
    "type": "content_grid",
    "version": 2,
    "values": {
      "items": [
        { "title": "Fast", "desc": "Sub-50ms TTFB" },
        { "title": "Secure", "desc": "Go-based core" }
      ]
    }
  }
]
```

**Key Constraints:**
*   **vibe:// Protocol:** All-media references in `blocks_data` use a internal protocol URI. This allows the CMS to swap S3 buckets or CDN hostnames without performing a search-and-replace on the JSON data.
*   **Strict Typing:** The `values` object is validated against a JSON Schema defined in the theme's `blocks/{type}.json` file.

### 2.4 Schema-on-Read (Transformation Layer)

To maintain the sub-50ms performance target, VibeCMS avoids blocking database migrations when a block’s structure changes (e.g., adding a new field to a "Hero" block). Instead, it uses a **Transformation Layer** in Go.

**The Workflow:**
1.  **Fetch:** The node is retrieved from Postgres.
2.  **Identify:** The system checks `schema_version` of the node and the `version` of individual blocks.
3.  **Transform:** If `block.version` is `1` but the current theme requires `2`, a Go-based "Transfomer" function runs in-memory:
    ```go
    // Conceptual Go Logic
    if block.Version == 1 && targetVersion == 2 {
        block.Values["new_field"] = block.Values["old_field_name"] // Mapping
        delete(block.Values, "old_field_name")
        block.Version = 2
    }
    ```
4.  **Render:** The transformed JSON is passed to the Jet template. The database is **not** updated during this read, keeping the operation extremely fast and preventing write-locks during traffic spikes.

### 2.5 Multi-Language and Localization Routing

The Universal Node structure handles localization natively through the `language_code` and `translation_group_id` (optional field).

*   **URL Strategy:** The router interprets paths based on the `language_code`.
    *   `GET /about-us` -> Queries `slug = 'about-us' AND language_code = 'en'`
    *   `GET /sk/o-nas` -> Queries `slug = 'o-nas' AND language_code = 'sk'`
*   **Data Isolation:** Each translation is a full, independent row in the `content_nodes` table. This allows different languages to have entirely different block structures (e.g., a "US-only" promo block) without complex conditional logic within a single shared JSON object.

### 2.6 Versioning and Point-in-Time Recovery

VibeCMS implements an "Append-Only" logic for content changes via a secondary `node_versions` table.

*   Every time a `content_node` is saved, the previous `blocks_data` and `metadata` are archived in `node_versions`.
*   The `Admin-Manager` role can trigger a "Restore" which moves the JSONB blob from the versioning table back into the `content_nodes` primary table.
*   To prevent database bloat, the internal Cron system (`Section 11`) automatically prunes versions older than 30 days or exceeding 50 entries per node, unless marked as a "Milestone Save."

### 2.7 AI Metadata Suggestions Integration

The `metadata` JSONB field is specifically partitioned to separate "Confirmed" metadata from "AI Suggestions."

```json
"metadata": {
  "seo": {
    "title": "Confirmed SEO Title",
    "description": "Manually set description."
  },
  "ai_suggestions": {
    "generated_at": "2023-10-27T10:00:00Z",
    "titles": ["VibeCMS: The Speed King", "Revolutionizing Go-Based CMS"],
    "description": "Suggested description based on block content analysis..."
  }
}
```
During the rendering of the Admin UI (HTMX + Alpine.js), these suggestions are displayed as "Quick Apply" buttons. This separation ensures that the 50ms TTFB public rendering pipeline only processes the `seo` object, ignoring the heavier `ai_suggestions` payload.

## Section 3: Block-Based Editor and JSON-Schema First Design

VibeCMS utilizes a "Schema-First" philosophy for content representation, moving away from traditional HTML-blob persistence in favor of a strictly typed, recursive block architecture stored as `JSONB` in PostgreSQL. This design ensures that every piece of content is predictable, machine-readable for AI-native workflows, and optimized for high-performance rendering via the Go-based Jet engine.

### 3.1 The Block Data Model
Content within the `blocks_data` field of the `content_nodes` table is structured as an array of JSON objects. Each block must conform to a specific structure that allows the VibeCMS core to route it to the correct renderer and validation logic.

#### Block Object Specification
```json
{
  "id": "uuid-v4-string",
  "type": "hero_section",
  "version": "1.0.0",
  "settings": {
    "background_color": "#ffffff",
    "is_full_width": true
  },
  "content": {
    "headline": "Empowering Agencies with Go",
    "subline": "Sub-50ms TTFB guaranteed.",
    "cta_text": "Get Started",
    "cta_link": "/contact",
    "image_id": "media-uuid-123"
  },
  "children": []
}
```

*   **Type Identifier:** A unique string (e.g., `hero_section`, `pricing_table`) that maps directly to a `.jet` template in `/themes/{active}/blocks/{type}.jet`.
*   **Version Tracking:** Supports the **Schema-on-Read** strategy. If a block's structure evolves, the version allows the Go transformation layer to patch data at runtime without modifying the database.
*   **Recursive Nesting:** The `children` array allows for complex layouts (e.g., a `column_layout` block containing multiple `text_block` children), enabling a "Lego-like" composition.

### 3.2 JSON-Schema Driven UI Generation
The Admin UI does not use hard-coded forms for block editing. Instead, it dynamically generates an interface using **HTMX** and **Alpine.js** based on a `schema.json` file located within each block's directory in the theme.

#### Schema Definition Example (`/themes/default/blocks/hero_section/schema.json`)
```json
{
  "$schema": "https://vibecms.com/schemas/block.v1.json",
  "name": "Hero Section",
  "fields": [
    {
      "name": "headline",
      "type": "text",
      "label": "Main Headline",
      "placeholder": "Enter a catchy title",
      "validation": { "required": true, "max_length": 120 }
    },
    {
      "name": "cta_link",
      "type": "relationship",
      "label": "Button Link",
      "config": { "target_node_types": ["page", "post"] }
    },
    {
      "name": "image_id",
      "type": "media",
      "label": "Background Image",
      "config": { "allowed_types": ["image/webp", "image/jpeg"] }
    }
  ]
}
```

#### Field Type Support
VibeCMS supports core "Vibe-Fields" that handle complex data relations and UI interactions:
1.  **Text/RichText:** Standard strings or sanitized HTML fragments.
2.  **Media:** Returns a UUID linking to the Media Manager. The UI triggers the S3-powered media picker.
3.  **Relationship:** A searchable dropdown populated via HTMX that links to other UUIDs in `content_nodes`.
4.  **Repeater:** An array of sub-fields (e.g., for accordion items or slider slides).
5.  **Select/Toggle:** Basic configuration flags stored in the `settings` object.

### 3.3 The "AI-Native" Integration
Because every block is governed by a JSON-Schema, the system can feed the schema directly into an LLM (OpenAI/Anthropic) to generate valid, structured content.

*   **In-Context Generation:** When an editor clicks "AI Suggest," VibeCMS sends the block type's schema and the current page context (title, keywords) to the AI provider.
*   **Validation:** The Go backend validates the AI's JSON response against the block's `schema.json` before presenting it to the editor. This prevents "hallucinated" fields from corrupting the `blocks_data` JSONB field.
*   **Structured Rewriting:** Editors can highlight specific block content and ask the AI to "shorten" or "reword," with the AI returning only the specific JSON leaf-nodes required for the update.

### 3.4 Admin Interaction Model (HTMX + Alpine.js)
The block editor provides a "Visual-ish" editing experience without the overhead of a heavy React/Vue SPA.

*   **State Management:** Alpine.js manages the local state of the block (e.g., open/closed accordions, temporary input values).
*   **Persistence:** Every change triggers a debounced `PATCH` request via HTMX to `/admin/api/nodes/{id}/blocks`. The backend performs a partial update on the JSONB column.
*   **Sorting:** Drag-and-drop reordering is handled by `SortableJS`. Upon a drop event, Alpine.js updates the index order of the blocks, and HTMX pushes the updated array order to the server.
*   **Real-time Preview:** An `<iframe>` or a targeted `<div>` reloads the partial Jet template of the modified block, providing instant visual feedback at server-side speeds.

### 3.5 Schema-on-Read Transformation Layer
To achieve the sub-50ms TTFB, VibeCMS avoids blocking database migrations. When the Go backend retrieves `blocks_data`, it passes the JSON through a Register of Transformers.

**Execution Flow:**
1.  Fetch `blocks_data` from PostgreSQL.
2.  Iterate through blocks; check `version` field.
3.  If `block.version < current_schema.version`, execute the corresponding Go transformation function.
    *   *Example:* Mapping `old_headline_key` to `new_title_key`.
4.  Pass the transformed, normalized JSON object to the **Jet** engine for final rendering.

This strategy ensures that content created three years ago remains compatible with the current theme templates without ever running a `VACUUM` inducing `UPDATE` on the database.

### 3.6 Implementation Constraints for Developers
*   **Schema Strictness:** Any field found in the `blocks_data` JSON that is not defined in the block's `schema.json` is stripped upon save to prevent "database drift."
*   **No Raw HTML in Blocks:** Content must be stored as raw data (strings, numbers, booleans). HTML generation is strictly the responsibility of the `.jet` templates to ensure SEO consistency (Schema.org injection) and performance.
*   **File Organization:**
    *   `themes/{theme}/blocks/{type}/schema.json` (Required)
    *   `themes/{theme}/blocks/{type}/{type}.jet` (Required)
    *   `themes/{theme}/blocks/{type}/preview.png` (Optional, for block selector UI)

## Section 4: Zero-Rebuild Extensibility via Tengo Scripting Engine

To achieve the vision of a high-performance CMS that avoids the "rebuild friction" of compiled Go binaries, VibeCMS implements a "Zero-Rebuild" extensibility layer using the **Tengo** scripting engine. This allows agencies to inject complex business logic, handle form submissions, and manipulate data contexts dynamically without interrupting the sub-50ms TTFB rendering pipeline or requiring a server restart.

### 4.1. Implementation Architecture
Tengo (a small, dynamic, and fast script language written in Go) acts as the bridge between the high-performance Go core and the flexible requirements of individual client sites. Scripts are treated as first-class citizens within the theme structure, stored as `.tgo` files.

*   **Engine Integration:** VibeCMS embeds the Tengo VM directly into the request-response lifecycle. Each script execution occurs in a sandboxed environment with limited resource allocation to prevent memory leaks or infinite loops from crashing the main process.
*   **File-Based Lifecycle:** Scripts reside in `/themes/{name}/scripts/`. The CMS monitors this directory. In development mode, scripts are re-parsed on every execution. In production, compiled bytecode is cached in memory, only refreshing if the file's MD5 hash changes, ensuring near-native execution speeds.
*   **The `vibe` Global Object:** To maintain security and performance, scripts do not have access to the Go standard library or raw SQL. Instead, all interaction occurs through a pre-bound global object named `vibe`.

### 4.2. Secure Scripting Sandbox (`vibe` Object API)
The `vibe` object is a restricted set of Go-mapped functions and maps that allow scripts to interact with the CMS state. Any attempt to use `os`, `exec`, or `net/http` directly from Tengo will result in a runtime error.

#### Supported Data Methods:
*   **`vibe.context` (Map):** A mutable map containing the current request context (headers, query params, URL segments).
*   **`vibe.data` (Map):** The data passed to the template. Scripts can inject new keys here for use in Jet/Templ templates.
*   **`vibe.fetch(url, options)`:** A controlled HTTP client for external API integrations (e.g., fetching weather, stock rates, or CRM syncing).
*   **`vibe.node` (Object):** Read-only access to the current `content_nodes` metadata (ID, Slug, CreatedAt).
*   **`vibe.log(message)`:** Interfaces with the internal VibeCMS logging system for debugging.

### 4.3. Execution Hooks (Trigger Points)
Scripts are not executed randomly; they are tied to specific system "Hooks." 

| Hook Name | File Pattern | Priority | Use Case |
| :--- | :--- | :--- | :--- |
| **Pre-Render** | `pre_render.tgo` | High | Modifying `vibe.data` before Jet templates are initialized. |
| **Post-Render** | `post_render.tgo` | Low | Injecting custom headers (e.g., Security headers) or manipulating the final HTML string. |
| **Form Submit** | `{form_id}.tgo` | Critical | Processing POST data, validation, and triggering `vibe.email()`. |
| **Cron Task** | `task_{name}.tgo` | Background | Scheduled logic handled by the Internal Cron sidecar process. |

### 4.4. Code Example: Dynamic Data Injection
This example demonstrates a script located at `/themes/modern/scripts/pre_render.tgo`. It fetches a "Member Count" from an external API and injects it into the landing page context.

```tengo
// /themes/modern/scripts/pre_render.tgo
fmt := import("fmt")

// Only run this logic for the homepage
if vibe.node.slug == "index" {
    resp := vibe.fetch("https://api.agency-dashboard.com/v1/stats", {
        method: "GET",
        headers: { "Authorization": "Bearer " + vibe.env("API_KEY") }
    })

    if resp.status_code == 200 {
        // Inject data for the Jet template to consume
        vibe.data.member_count = resp.json().total_active
        vibe.data.show_stats_banner = true
    } else {
        vibe.log(fmt.sprintf("Failed to fetch stats: %d", resp.status_code))
        vibe.data.show_stats_banner = false
    }
}
```

In the corresponding `blocks/hero.jet` file, the developer simply uses:
```jet
{{ if show_stats_banner }}
    <div class="banner">Join {{ member_count }} active members!</div>
{{ end }}
```

### 4.5. Form Handling and Submission Pipeline
The Zero-Rebuild approach is most powerful in handling custom forms. Instead of writing Go controllers for every unique form, agencies use the following workflow:

1.  **Define Form:** The editor adds a block with `form_id: "newsletter_signup"`.
2.  **Logic File:** Create `/themes/{name}/scripts/newsletter_signup.tgo`.
3.  **Processing:**
    *   VibeCMS traps the POST request.
    *   It looks for a `.tgo` file matching the `form_id`.
    *   The script validates the input and interacts with the `vibe.mail` or `vibe.db_log` utilities.
    *   The script returns a redirect or a JSON success message for HTMX to swap.

### 4.6. Performance Constraints and Edge Cases
To ensure the **sub-50ms TTFB** target, the following constraints are enforced:

*   **Timeout Limits:** Script execution is capped at **15ms**. If a script exceeds this, the VM is killed, an error is logged, and the page renders with the original context to prevent a site-wide hang.
*   **Memory Ceiling:** Each script is limited to **4MB** of heap memory.
*   **Global Variable Persistence:** Unlike Go, Tengo global variables do not persist between requests. Each request creates a fresh VM instance. State must be persisted via the PostgreSQL `JSONB` store or external APIs.
*   **Error Handling:** In production, Tengo syntax errors inhibit only the extension logic, not the core page load. If `pre_render.tgo` fails, the system falls back to the raw JSON data from `blocks_data` to ensure the site remains accessible.

### 4.7. AI-Native Extensibility
Because Tengo scripts use a Go-like syntax and the `vibe` object follows a strict schema, AI agents can generate `.tgo` files with high accuracy. The `vibe-fields` and JSON-Schema definitions for blocks provide the necessary context for an LLM to write functional business logic (e.g., "Write a Tengo script that takes the Contact Form input and sends an email via Resend"). This aligns with the "AI-Native" core goal of VibeCMS by making the logic layer as readable and writable by machines as the content itself.

## Section 5: High-Performance Rendering Pipeline (Jet/Templ)

The VibeCMS rendering pipeline is the mission-critical engine responsible for achieving the **sub-50ms TTFB target**. It achieves this by bypassing the overhead typical of interpreted CMS platforms (like PHP-based WordPress) and instead utilizing a tiered compilation and streaming strategy. The pipeline integrates Go's memory safety and speed with two distinct templating technologies: **Jet** (for flexible, high-performance theme development) and **Templ** (for type-safe, component-based Admin UI and Core elements).

### 5.1 Dual-Engine Architecture Strategy

VibeCMS employs a "Right Tool for the Job" approach to rendering:

| Feature | Jet Engine (Theme Layer) | Templ Engine (Core/Admin Layer) |
| :--- | :--- | :--- |
| **Primary Use** | Public-facing themes, user blocks, layouts. | Admin UI components, system dashboards. |
| **Performance** | Extremely fast (compiles to Go bytecode). | Compiled to native Go code (fastest possible). |
| **Syntax** | Twig/Smarty-like (Designer friendly). | Type-safe Go functions (Developer centric). |
| **Hot Reload** | Supported (Template parsing at runtime). | Requires compilation (Built into Vibe binary). |
| **Extension** | `tgo` script integration into context. | Hard-coded Go logic and Alpine.js. |

### 5.2 The "Vibe Loop" Rendering Sequence

The public-facing rendering process follows a strict execution order to minimize latency:

1.  **Direct Route Matching:** The Fiber/Echo router identifies the `slug` and retrieves the `ContentNode` from the `content_nodes` table. A `SELECT` query targets only specific `JSONB` fields needed for the initial head-render.
2.  **Schema-on-Read Transformation:** If the `blocks_data` version in the database is lower than the current theme's requirements, a transformation layer maps old keys to new keys in-memory without a database write.
3.  **Tengo Hook (Pre-Render):** The engine checks for `themes/{active}/scripts/pre_render.tgo`. This script can inject dynamic data (e.g., "Current Stock" from an external API) into the global `vibe` object passed to Jet.
4.  **Layout Initialization:** The pipeline loads `themes/{active}/layouts/main.jet`. 
5.  **Block Iteration (The Core Loop):**
    *   The engine iterates over the `blocks_data` JSON array.
    *   For each entry `{ "type": "hero", "data": {...} }`, it resolves the template at `themes/{active}/blocks/hero.jet`.
    *   If a block template is missing, it falls back to a hidden `sys_error_block.jet` to prevent page crashes.
6.  **Fragment Streaming:** HTML is buffered and streamed to the client, ensuring the browser can begin parsing the `<head>` and CSS while the footer and lower blocks are still being processed.

### 5.3 Jet Engine Implementation & Optimization

Jet is selected for the public-facing content because it offers a performance profile nearly identical to Go's `html/template` but with a syntax specialized for CMS development.

#### 5.3.1 Template Caching & Monitoring
In production mode, Jet templates are parsed once and stored in a `map[string]*jet.Template`. VibeCMS implements an **In-Memory LRU Cache** for compiled block fragments.
*   **Dev Mode:** A `fsnotify` watcher monitors the `/themes/` directory. On file change, the Jet set is cleared, allowing for instant feedback without server restarts.
*   **Prod Mode:** Templates are immutable in memory. The system uses `sync.Pool` to reuse `jet.VarMap` objects, significantly reducing GC pressure during high-traffic spikes.

#### 5.3.2 Global Context (The `vibe` Object)
Every Jet template has access to a standardized `vibe` object. Constraints for this object include:
*   `vibe.Site`: Global settings (Title, Analytics IDs).
*   `vibe.Page`: Metadata for the current node (SEO tags, canonical URL).
*   `vibe.User`: Auth state (if the visitor is logged into a protected section).
*   `vibe.Blocks`: The actual JSONB content mapped to Go structs.

### 5.4 Templ: Type-Safe Component Rendering

For the Admin UI and critical system views, VibeCMS uses **Templ**. This ensures that complex UI interactions (managed via HTMX and Alpine.js) are backed by the Go compiler.

#### 5.4.1 Component-Based Design
Templ allows the definition of reusable components (e.g., `MediaPicker`, `SettingsToggle`) that are compiled directly into the VibeCMS binary. 
*   **Zero-Overhead:** Since Templ generates Go code, there is no parsing or reflection at runtime.
*   **Integration:** Templ components generate standard `io.Writer` output, allowing them to be nested inside Jet layouts if high-security or complex logic is required within a theme.

### 5.5 High-Performance Constraints & Guardrails

To maintain the **sub-50ms TTFB**, the following rendering constraints are enforced:

1.  **Max Block Nesting:** The JSONB `blocks_data` parser limits recursion depth to **5 levels**. This prevents circular reference attacks and stack overflows.
2.  **No Direct DB in Templates:** Templates (Jet) and components (Templ) are strictly prohibited from initiating database queries. All data must be fetched by the Go handler or injected via a Tengo script prior to the rendering start.
3.  **Asset Fingerprinting:** A native Jet function `{{ vibe_asset("js/main.js") }}` automatically appends a content hash (via `sha256` of the file) and prepends the S3/CDN URL, ensuring efficient caching and zero "stale" assets.
4.  **Automatic WebP Injection:** The pipeline includes a middleware that scans the rendered HTML (post-Jet) and replaces standard `<img>` tags for internal assets with `<picture>` tags containing the WebP source generated by the Media Manager, provided the user-agent supports it.

### 5.6 Edge Case: Schema Evolution (Schema-on-Read)

When a developer updates a block's requirements (e.g., adding a "Button Color" field to a "Call to Action" block), the rendering pipeline handles the migration on-the-fly:

```go
// Simplified Logic in the Rendering Engine
func resolveBlockData(rawData json.RawMessage, version int) (interface{}, error) {
    if version < current_theme_version {
        // Apply transformation logic stored in /themes/{name}/schema_updates.tgo
        return transformViaTengo(rawData, version)
    }
    return unmarshalToCurrentStruct(rawData)
}
```
This avoids `UPDATE content_nodes SET blocks_data = ...` operations across thousands of rows, maintaining performance during site-wide redesigns or theme updates.

### 5.7 Performance Metrics Tracking
The pipeline includes a "Tracing" mode (gated by a `VIBE_DEBUG` env var) that injects an HTML comment at the end of every request:
`<!-- VibeCMS Render: DB: 4ms | Tengo: 2ms | Jet: 12ms | Total: 18ms -->`.
This allows agencies to verify the **sub-50ms target** directly from the browser inspector during development.

## Section 6: Admin UI and Interaction Model (HTMX + Alpine.js)

The VibeCMS Admin UI is engineered to provide a "Single Page App (SPA) feel" without the architectural overhead, bundle size, or SEO complexities of a heavy JavaScript framework. By utilizing **HTMX** for server-side fragment swapping and **Alpine.js** for localized client-side reactivity, the administrative interface maintains the project's core "Go-first" philosophy while ensuring a fluid experience for agencies managing complex block-based content.

### 6.1 Architectural Principles: The "Hypermedia-Driven" Admin
The Admin UI operates on the principle of **Hypermedia as the Engine of Application State (HATEOAS)**. Instead of the client managing complex state machines and synchronizing JSON with the backend via a REST/GraphQL API, the Go server (Fiber/Echo) remains the single source of truth.

*   **HTMX for State Transitions:** Every administrative action—saving a page, toggling a setting, or reordering a block—is initiated by an HTMX request (`hx-post`, `hx-put`, `hx-delete`). The server responds with partial HTML fragments (rendered via Jet or Templ) that HTMX swaps into the DOM.
*   **Alpine.js for Low-Latency Interactivity:** For UI states that do not require server persistence (e.g., opening a dropdown, toggling a tab, or real-time character counting), Alpine.js provides a declarative, lightweight directive system.
*   **Sub-100ms Admin Interaction:** While the public frontend targets <50ms TTFB, the Admin UI targets <100ms for interaction swaps to ensure the interface feels instantaneous to the editor.

### 6.2 The Block Editor Interaction Model
The centerpiece of the Admin UI is the **Dynamic Block Builder**. This interface allows editors to manipulate the `blocks_data` JSONB field through a visual, drag-and-drop interface.

#### 6.2.1 Component Anatomy
Each block in the editor is encapsulated in a Jet template fragment located at `/internal/admin/templates/components/block_wrapper.jet`. 
- **The Wrapper:** Provides the HTMX hooks for deletion and reordering.
- **The Form:** Generated dynamically from the block's `JSON-Schema`.
- **The Preview:** An iframe or inline div showing the block rendered with the active theme's CSS.

#### 6.2.2 Drag-and-Drop Implementation
To handle reordering without a heavy JS library, VibeCMS integrates **SortableJS** with an HTMX closure.
```html
<div id="block-list" 
     hx-post="/admin/nodes/reorder" 
     hx-trigger="end" 
     hx-target="#block-list"
     x-init="new Sortable($el, { animation: 150, handle: '.drag-handle' })">
    <!-- Loop through blocks_data and render block_wrapper.jet -->
</div>
```
When a drag operation ends, SortableJS triggers the `end` event. HTMX catches this, gathers the new sequence of block IDs from the DOM, and sends a `POST` request to the Go backend. The backend updates the JSONB array in PostgreSQL and returns the updated HTML list.

### 6.3 Real-Time Schema-to-Form Generation
VibeCMS uses a "Schema-First" approach. When a user adds a new block type, the Admin UI interprets the block's JSON Schema to render the appropriate inputs.

| Field Type | Admin UI Component | Implementation |
| :--- | :--- | :--- |
| `String` | `input type="text"` | Standard HTML with Alpine.js validation. |
| `RichText` | `Tiptap` / `TinyMCE` | Initialized via an Alpine.js `x-init` hook. |
| `Media` | `VibeMediaPicker` | Opens a modal; returns a UUID/S3 Path via HTMX swap. |
| `Repeater` | `Alpine loop` | Local state manages addition/removal; HTMX persists on Save. |
| `Relationship` | `TomSelect` / `Choices.js` | Fetches other `content_nodes` via HTMX search endpoint. |

### 6.4 AI-Integration UI Hooks
As an AI-Native CMS, the Admin UI features explicit hooks for metadata and content generation.
- **The "Magic Wand" Button:** Adjacent to text fields, an HTMX-driven button (`hx-get="/admin/ai/suggest?field=meta_title"`) triggers the Go backend to query the LLM.
- **The Streamed Response:** To avoid UI freezing during AI generation, VibeCMS uses **Server-Sent Events (SSE)** via HTMX's `sse` extension. The AI suggestions stream directly into the Alpine.js data model, appearing to the user in real-time.

### 6.5 Media Manager Interaction
The Media Manager is implemented as a slide-over or modal component that uses HTMX for infinite scrolling.
1. **Upload Workflow:** Alpine.js intercepts the file drop, performs client-side validation, and hands the payload to HTMX for a `multipart/form-data` POST.
2. **Processing Feedback:** As the Go backend optimizes the image to **WebP**, it pushes progress updates back to the UI.
3. **Selection:** Clicking an image sends the Asset UUID back to the parent block's input field using the `HTMX:afterRequest` event or a custom `dispatch` in Alpine.js.

### 6.6 Global Constraints & Form Validation
To ensure data integrity before the Transformation Layer saves to the `content_nodes` table, the Admin UI employs a dual-layer validation strategy:
- **Client-Side (Alpine.js):** Uses the `x-model` and native HTML5 validation API to provide immediate feedback (e.g., "Field required" or "Max 60 characters").
- **Server-Side (Go + HTMX):** Upon `hx-post`, the Go backend validates the fragment. If validation fails, the server returns the form fragment with a `422 Unprocessable Entity` status code, and HTMX swaps only the error messages into the DOM, preserving the user's current input.

### 6.7 State Persistence & Personalization
The Admin UI tracks session-based state (e.g., "Sidebar Collapsed," "Editor Theme," "Last Filtered Node Type") using **PostgreSQL-backed User Preferences**.
- **Interaction:** Toggling the sidebar triggers an `hx-patch="/admin/user/prefs"` request.
- **Benefit:** This ensures that when an Agency-Manager logs in from a different machine, their workflow environment is perfectly restored without relying on fragile `localStorage`.

### 6.8 The "Zero-Refresh" Update Pipeline
Updates to the system (license verification, theme hot-reloads, or Tengo script updates) are reflected in the Admin UI via an HTMX polling mechanism or WebSockets for Agency-Manager roles. 
- **Notification Toast:** When a Tengo script is saved and successfully compiled into a VM, a `vibe-check-success` event is dispatched. Alpine.js listens for this event to trigger a toast notification:
  ```html
  <div @vibe-check-success.window="showToast('Logic Updated Offline', 'success')"></div>
  ```

This interaction model ensures that the CMS remains extremely lightweight (no multi-megabyte JS bundles), maintainable by Go developers, and provides the instant feedback loop required by modern agencies.

## Section 7: Media Management and Automated WebP Optimization

VibeCMS treats media as a first-class performance citizen. To maintain the project-wide target of a **sub-50ms TTFB**, the media pipeline is designed to eliminate high-latency disk I/O and unoptimized payloads. The system enforces a strict state-less architecture, offloading all binary storage to S3-compatible providers while handling compute-intensive image transformations through a non-blocking Go-based processing pipeline.

### 7.1 Architecture and Storage Strategy
VibeCMS ignores local filesystem storage for production media to ensure horizontal scalability and deployment parity.

*   **Storage Protocol:** All media interactions must use the **S3-compatible API**. Supported providers include AWS S3, DigitalOcean Spaces, Cloudflare R2, and Backblaze B2.
*   **Local Development:** For local development environments, **MinIO** is the mandated mock. The CMS configuration includes an `S3_ENDPOINT` variable that redirects the Go S3 SDK to the local MinIO container, ensuring developers never write to local disk in a way that differs from production.
*   **Database Reference:** Media metadata is stored in the `media_assets` table. This includes the S3 Object Key, MIME type, dimensions (width/height), and a JSONB field for alternative text and focal point coordinates.

### 7.2 The Automated WebP Pipeline
Upon upload via the Admin UI (HTMX-powered), VibeCMS initiates an asynchronous optimization routine. The original file is preserved as a "Source of Truth," but the public-facing delivery layer is strictly limited to optimized formats.

#### 7.2.1 Optimization Logic
When a file (JPEG, PNG, or TIFF) is POSTed to the `/admin/api/media/upload` endpoint, the following sequence occurs:
1.  **Validation:** The file is checked against a whitelist of supported move/image types.
2.  **Original Persistence:** The raw file is uploaded to the S3 bucket's `originals/` prefix.
3.  **Go Routine Fan-out:** A background worker is spawned using a worker pool to prevent CPU exhaustion during high-concurrency uploads.
4.  **WebP Conversion:** Using a Go-native imaging library (e.g., `disintegration/imaging` or `h2non/bimg` utilizing `libvips`), the image is:
    *   Stripped of EXIF metadata (Security & Privacy).
    *   Resized to a "Master" resolution (max width 3840px).
    *   Converted to **WebP** with a targeted quality variable (defaulting to 80).
5.  **Variant Generation:** The system automatically generates standardized responsive variants:
    *   `thumb`: 150x150 (Square Crop)
    *   `sm`: 640px wide (Auto height)
    *   `md`: 1280px wide (Auto height)
    *   `lg`: 1920px wide (Auto height)
6.  **S3 Sync:** Variants are uploaded to the `processed/` prefix with a content-type of `image/webp`.

### 7.3 Jet Template Integration
To leverage the optimized assets without manual URL construction, VibeCMS provides a custom Jet function: `vibe_media(asset_id, size)`.

```jet
{{/* Example of rendering an optimized image in a block */}}
<picture>
    <source srcset="{{ vibe_media(block.image_id, 'lg') }}" type="image/webp">
    <img src="{{ vibe_media(block.image_id, 'md') }}" 
         alt="{{ block.image_alt }}" 
         loading="lazy" 
         class="vibe-optimized-image">
</picture>
```

The `vibe_media` function performs an in-memory look-up of the asset's URI, prepending the configured CDN/S3 URL. It supports high-performance caching to ensure the look-up does not impact the 50ms TTFB budget.

### 7.4 Admin UI Media Manager (HTMX + Alpine.js)
The Media Manager is integrated into the block-based editor as a modal-based gallery. 

*   **Lazy Loading:** The gallery uses Alpine.js `x-intersect` to lazy-load thumbnails as the user scrolls.
*   **Drag-and-Drop:** Built using Alpine.js and the HTML5 Drag and Drop API, allowing bulk uploads. 
*   **Real-time Progress:** HTMX handles the multi-part form submission, while the server streams progress events via SSE (Server-Sent Events) to update a progress bar in the UI.
*   **Search and Filter:** The `media_assets` table is indexed via Gin index on a TSVector column, allowing instant full-text search across filenames and Alt text within the Admin UI.

### 7.5 Edge Cases and Constraints
*   **SVG Handling:** SVGs bypass the WebP conversion pipeline but are passed through an XML sanitizer to remove potential XSS vectors (e.g., `<script>` tags or `onmouseover` attributes) before being stored.
*   **GIFs:** Depending on the available system libraries (libvips), GIFs are either converted to animated WebP or maintained as optimized GIFs.
*   **Zero-Rebuild Logic:** Tengo scripts can access media metadata via the `vibe.media.get(id)` global object, enabling developers to build custom logic such as "Media Expiration" or "Dynamic Watermarking" (if proxied through a Go handler).
*   **Memory Management:** To prevent OOM (Out of Memory) errors during large image processing, the Go worker pool is limited to `runtime.NumCPU()` concurrent tasks, with a maximum buffer size for the conversion queue.

### 7.6 Optimization Configuration (config.yaml)
Agencies can fine-tune the media behavior per instance:
```yaml
media:
  provider: "s3"
  s3:
    bucket: "client-site-assets"
    region: "us-east-1"
    endpoint: "https://r2.cloudflare.com" # Or MinIO for local
  optimization:
    format: "WebP"
    quality: 82
    max_width: 3840
    strip_metadata: true
    responsive_sizes:
      sm: 640
      md: 1280
      lg: 1920
```

This architecture ensures that even if an editor uploads a 20MB 4K JPEG, the public visitor will only ever receive a highly compressed, appropriately sized WebP asset, safeguarding the site's Core Web Vitals and maintaining the "Vibe" of high-performance delivery.

## Section 8: Native SEO Suite and AI-Generated Metadata Suggestions

VibeCMS integrates a high-performance, automated SEO engine designed to eliminate the manual overhead typically associated with technical search engine optimization. By leveraging the project's sub-50ms TTFB architecture and JSONB content structure, the SEO suite provides real-time metadata generation, structured data injection, and AI-assisted optimization without compromising server response times.

### 8.1 Automated Metadata Orchestration
The SEO engine operates as a middleware layer within the rendering pipeline. Before the Jet or Templ engines generate the final HTML, the system aggregates SEO data from three hierarchical sources:

1.  **Manual Overrides:** Explicitly defined values in the `content_nodes` metadata fields.
2.  **AI Suggestions:** Suggestions generated by the integrated LLM, which remain as "pending" until manually committed by an Editor or Admin.
3.  **Heuristic Fallbacks:** Automated extraction logic that pulls from the `blocks_data` JSONB field (e.g., using the first `H1` for the Title tag and the first 160 characters of the primary `text` block for the Description).

#### Technical Implementation: Metadata Resolver
```go
// Internal representation of the SEO Context passed to Jet templates
type SEOContext struct {
    Title          string            `json:"title"`
    Description    string            `json:"description"`
    CanonicalURL   string            `json:"canonical_url"`
    OGImage        string            `json:"og_image"`
    OGType         string            `json:"og_type"`
    Robots         string            `json:"robots"` // e.g., "index, follow"
    SchemaJSON     string            `json:"schema_json"`
    AlternateLinks map[string]string `json:"alternate_links"` // For multi-language /en/ vs /sk/
}
```

### 8.2 AI-Generated Metadata Suggestions
VibeCMS utilizes an integrated AI-native workflow to assist editors in crafting high-conversion metadata. This system is triggered within the Admin UI (powered by HTMX and Alpine.js) and interfaces with the configured LLM.

*   **Contextual Analysis:** The system sends a stripped-down JSON representation of the `blocks_data` to the AI provider. This ensures the AI understands the actual content of the page rather than just the title.
*   **Prompt Engineering:** The internal prompt instructs the AI to generate:
    *   An SEO Title (max 60 chars) incorporating primary keywords.
    *   A Meta Description (max 160 chars) with a clear Call to Action (CTA).
    *   Five relevant keywords for internal tagging.
    *   An OpenGraph (OG) summary for social sharing.
*   **Non-Blocking Persistence:** AI suggestions are stored in a temporary `seo_suggestions` JSONB column within the `content_nodes` table. They are *never* automatically published to the live site to prevent "hallucinated" content from impacting brand reputation. Editors must click "Apply AI Suggestion" to move the data into the active metadata fields.

### 8.3 Real-Time Sitemap.xml Engine
To maintain the 50ms TTFB target, VibeCMS avoids generating the sitemap on every request. Instead, it utilizes an **In-memory Sitemap Cache Strategy**.

*   **Generation Trigger:** The sitemap is regenerated only when a `content_node` is published, deleted, or its `slug` is modified.
*   **Optimization:** The generator performs a targeted query on `content_nodes`, selecting only `slug`, `updated_at`, and `seo_priority` where `is_published` is true and `no_index` is false.
*   **Caching:** The resulting XML is stored in a global `sync.Map` or a similar thread-safe memory buffer. Requests to `/sitemap.xml` are served directly from this buffer, achieving sub-5ms response times.
*   **Multi-Language Logic:** The sitemap automatically includes `xhtml:link` rel="alternate" tags based on the project's localization routing configuration (e.g., mapping `/about` to `/sk/o-nas`).

### 8.4 Native Schema.org Generation
VibeCMS provides native support for structured data without external plugins. Because the content is stored as structured blocks, the system can automatically map JSON data to Schema.org types.

| Block Type | Schema.org Mapping |
| :--- | :--- |
| `article_hero` | `NewsArticle` or `BlogPosting` |
| `faq_accordion` | `FAQPage` (Question/Answer entities) |
| `product_specs` | `Product` (Price, Availability, SKU) |
| `organization_info` | `LocalBusiness` or `Organization` |

Developers define schema mappings within the block's configuration. The `vibe` global object in Tengo can also be used to programmatically inject custom schema properties during the `pre_render.tgo` hook.

### 8.5 Robots.txt and Granular Indexing Controls
The CMS provides a dedicated interface in the Admin UI for managing `robots.txt` dynamically. 

*   **Global Rules:** Edit the global `robots.txt` file which is served via a high-priority Fiber/Echo route.
*   **Node-Level Overrides:** Each content node contains a `robots_config` JSONB field, allowing editors to set `noindex`, `nofollow`, `noarchive`, or `nosnippet` on a per-page basis.
*   **Environment Awareness:** In non-production environments (determined by an `ENV` variable), the system can be configured to automatically serve a `Disallow: /` header to prevent staging sites from being indexed.

### 8.6 Third-Party SEO API Integrations (Ahrefs/Semrush)
For Agency-Manager roles, VibeCMS supports optional integration with professional SEO tools.
*   **Metric Injection:** If an API key for Ahrefs or Semrush is provided, the Admin UI displays real-time backlink counts, domain rating, and organic traffic estimates for the current node.
*   **Health Checks:** The Agency Management API can aggregate these metrics across multiple VibeCMS instances, allowing agencies to monitor the SEO performance of their entire portfolio from a single dashboard.

### 8.7 Edge Cases and Constraints
*   **Slug Collisions:** The system enforces unique slugs per language. If a collision occurs, the SEO suite flags a warning in the Admin UI, as duplicate URLs negate SEO value.
*   **Zero-JS Metadata:** All SEO tags (Meta, OG, Canonical, Schema) are rendered server-side. There is no reliance on client-side JavaScript for metadata injection, ensuring 100% crawlability by search engine bots.
*   **Character Budgeting:** The Admin UI features real-time character counters for Title and Description fields, highlighting values in red if they exceed standard SEO limits.

## Section 9: Agency Management API and Health Monitoring

The Agency Management API is a critical performance-oriented and operational infrastructure component of VibeCMS. Designed for agencies managing 100+ independent site instances, this system provides a standardized, machine-readable gateway to monitor the health, security, and licensing status of every 1:1 deployment. By utilizing an API-key-based authentication model, agencies can aggregate data from disparate VibeCMS binaries into a centralized dashboard without manual intervention.

### 9.1 Technical Architecture of the Monitoring Layer
The monitoring system operates as a high-priority, low-overhead internal service within the Go (Fiber/Echo) application. To ensure that monitoring requests do not interfere with the `sub-50ms TTFB` target for public traffic, health checks utilize a dedicated middleware that short-circuits the standard routing logic and pulls metrics directly from the application's memory and the PostgreSQL `JSONB` schema-on-read layer.

#### 9.1.1 Security and Authentication
All Management API endpoints are gated by the `X-Vibe-Agency-Key`.
- **Key Generation:** Generated during the initial setup or via the Admin UI (RBAC: Admin only).
- **Storage:** Stored as a salted Argon2 hash in the system configuration table.
- **Scope:** Keys are instance-specific, adhering to the 1:1 deployment model.

### 9.2 Endpoint Specification: `/api/v1/management/health`
This primary endpoint returns a comprehensive snapshot of the instance's operational state.

**Method:** `GET`
**Response Format:** `application/json`

#### 9.2.1 Data Points and Schema
The JSON response is structured to provide telemetry across four critical dimensions:

| Category | Field | Description |
| :--- | :--- | :--- |
| **System** | `version` | Current VibeCMS binary version. |
| **System** | `uptime_seconds` | Seconds since the Go process started. |
| **System** | `go_routines` | Count of active goroutines (detecting leaks). |
| **Database** | `db_status` | Binary check (`reachable`, `latency_ms`). |
| **Database** | `migrations_sync` | Boolean: Does the DB match the expected schema version? |
| **Storage** | `s3_connection` | Status of the S3-compatible (MinIO/R2) link. |
| **Storage** | `storage_used_bytes` | Total size of assets tracked in the Media Manager. |
| **Licensing** | `license_status` | Status: `valid`, `expired`, `grace_period`, or `invalid`. |
| **Licensing** | `days_until_expiry` | Countdown for the domain-locked license key. |
| **Security** | `failed_logins_24h` | Number of unauthorized Admin UI attempts. |

**Example Response Payload:**
```json
{
  "instance_id": "vibe_7f4a2b9",
  "domain": "client-site.com",
  "status": "healthy",
  "timestamp": "2023-10-27T10:00:00Z",
  "metrics": {
    "ttfb_p95_ms": 38,
    "memory_usage_mb": 42.5,
    "cpu_usage_pct": 1.2
  },
  "services": {
    "postgres": "connected",
    "s3_storage": "connected",
    "cron_worker": "running"
  },
  "licensing": {
    "key_type": "Agency-Pro",
    "last_verified": "2023-10-27T04:00:00Z",
    "status": "active"
  },
  "updates": {
    "available": true,
    "current_version": "v1.0.4",
    "latest_version": "v1.0.8"
  }
}
```

### 9.3 Pulse Monitoring & Heartbeat Mechanism
To facilitate "push-button" monitoring from an agency's central command center, VibeCMS includes an optional **Heartbeat Outbound** service.
- **Function:** This is a background routine managed by the **Internal Cron System (Section 11)**.
- **Interval:** Configurable (default: every 15 minutes).
- **Payload:** A minified version of the health JSON sent via `POST` to a user-defined Webhook URL.
- **Failure Logic:** If the central dashboard is unreachable, the heartbeat logs the error locally and retries on the next interval.

### 9.4 Automated Health Checks & Self-Healing
The Agency Management layer is not purely passive; it implements basic self-healing triggers to maintain the 50ms TTFB goal:
1. **Database Connection Pool Reset:** If the `db_latency_ms` exceeds 200ms for three consecutive internal checks, the CMS attempts to gracefully drain and reset the PostgreSQL connection pool.
2. **S3 Mock Sync:** In development environments using **MinIO**, the health monitor verifies that the `local_development_s3_mock` is reachable, preventing media upload crashes during agency dev-sprints.
3. **Log Rotation:** If the local error logs or `vibe_mail_logs` table size exceeds 500MB, the management service triggers a `TRUNCATE` or archive task via the sidecar Cron process.

### 9.5 License Key Enforcement Middleware
As per the `Paid key per domain` model, the Management API contains the logic for **Section 13 (Licensing Enforcement)**.
- **Verification Loop:** Every 24 hours, the instance makes a silent, non-blocking outbound call to the VibeCMS License Server.
- **Grace Period Logic:** If the license server is down, the system maintains "Active" status for 7 days.
- **Failure State:** If verification fails (e.g., domain mismatch or expired key), the management API flags `license_status: "restricted"`. In this state:
    - The public-facing site remains operational (to honor the performance target).
    - The Admin UI displays a persistent "License Invalid" banner.
    - **Tengo Scripting Engine** enters a "read-only" mode where new `.tgo` scripts cannot be saved.

### 9.6 Update Notification API
Agencies managing hundreds of sites cannot check for updates manually. The Management API exposes a specific `/api/v1/management/updates` endpoint.
- **Version Comparison:** It compares the current binary build against the `vibecms.com/api/versions` manifest.
- **Change Log Parsing:** Returns a JSON list of "Breaking Changes," "Security Fixes," and "New Block Schemas."
- **Agency Action:** This allows external management tools (like MainWP or custom agency dashboards) to trigger a `git pull` or binary swap via SSH or CI/CD pipelines.

### 9.7 Performance Constraints
To ensure the Management API does not degrade site performance:
- **Internal Caching:** Metric data (CPU, Memory, DB status) is cached in-memory every 60 seconds. API requests return the cached value rather than performing real-time system calls.
- **JSONB Aggregation:** When reporting on content statistics (e.g., "Total Pages"), the API queries the `content_nodes` table using PostgreSQL's `jsonb_path_query_array` to ensure fast execution even with thousands of nodes.

## Section 10: Communication Layer (SMTP, Resend, and Email Logging)

The VibeCMS Communication Layer is a specialized subsystem designed to handle transactional and system-driven messaging with high reliability and full auditability. To maintain the project's **sub-50ms TTFB target**, all email dispatch operations are decoupled from the main request/response lifecycle. This section defines the architecture for multi-provider support, the asynchronous dispatching mechanism, and the persistent logging schema required for agency-level monitoring.

### 10.1 Provider Strategy and Configuration

VibeCMS supports two primary transport methods to balance universal compatibility with modern API-driven performance. Configuration is managed via the Admin UI (stored in PostgreSQL) and can be overridden by environment variables for CI/CD safety.

#### 10.1.1 Supported Providers
1.  **Standard SMTP:**
    *   **Core Use Case:** Legacy integrations, specialized private mail servers, or hardware-based relays.
    *   **Implementation:** Utilizes the native Go `net/smtp` package with support for PLAIN, LOGIN, and CRAM-MD5 authentication.
    *   **Security:** Mandatory TLS/SSL support (STARTTLS or Implicit TLS on port 465).
2.  **Resend.com (Native API):**
    *   **Core Use Case:** High-deliverability transactional mail with modern tracking and developer-friendly headers.
    *   **Implementation:** Custom Go HTTP client targeting the `https://api.resend.com/emails` endpoint.
    *   **Benefits:** Bypasses SMTP handshake overhead; provides superior metadata for "Delivered" and "Opened" statuses.

#### 10.1.2 Configuration Schema
Email settings are stored in a encrypted JSONB field within the system settings table:
```json
{
  "provider_active": "resend",
  "from_name": "VibeCMS Media",
  "from_address": "no-reply@vibe-instance.com",
  "reply_to": "support@agency-client.com",
  "smtp_config": {
    "host": "smtp.mailtrap.io",
    "port": 587,
    "user": "vibe_user",
    "pass": "ENCRYPTED_VAL",
    "encryption": "STARTTLS"
  },
  "resend_config": {
    "api_key": "re_123456789",
    "region": "us-east-1"
  }
}
```

### 10.2 Asynchronous Dispatch Pipeline (The "Mail Buffer")

To prevent external network latency from impacting the user experience, VibeCMS implements a **non-blocking internal queue**.

1.  **Trigger:** An event (e.g., Form Submission, Password Reset, License Alert) calls the internal `vibe.SendMail()` service.
2.  **Persistence:** The message object is immediately serialized into the `email_logs` table with a status of `pending`.
3.  **Queueing:** The record ID is passed to an internal Go channel (`chan uint64`).
4.  **Worker Execution:** A dedicated background worker (Go-routine) picks up the ID, selects the full row, and executes the dispatch via the active provider.
5.  **Status Update:** Upon completion (success or failure), the worker updates the log entry with the provider's response body and final status.

### 10.3 Email Logging and Diagnostics

Agencies managing hundreds of instances require visibility into delivery failures. VibeCMS maintains a strictly structured log of every message generated by the system.

#### 10.3.1 Database Schema: `email_logs`
| Field | Type | Description |
| :--- | :--- | :--- |
| `id` | UUID (PK) | Unique identifier for the log entry. |
| `id_node` | INT | Optional link to the `content_nodes` (e.g., which page triggered the form). |
| `recipient` | TEXT | To address. |
| `subject` | TEXT | Email subject line. |
| `body_html` | TEXT | Rendered HTML content (stored for audit/resend). |
| `provider` | VARCHAR(20) | `smtp` or `resend`. |
| `status` | VARCHAR(20) | `pending`, `sent`, `failed`, `bounced`. |
| `error_log` | TEXT | Raw error message from the provider if failed. |
| `provider_id` | TEXT | The unique ID returned by Resend or the SMTP Message-ID. |
| `created_at` | TIMESTAMP | Timestamp of creation. |
| `sent_at` | TIMESTAMP | Timestamp of successful transmission. |

### 10.4 Tengo Scripting Integration

A critical feature of the "Zero-Rebuild" philosophy is allowing developers to trigger emails from within `.tgo` scripts (e.g., custom lead routing). The `vibe` global object exposes a safe mailer interface:

```go
// Example: themes/default/scripts/contact_form.tgo
fn on_submit(data) {
    if data.email == "" { return }
    
    // Trigger asynchronous mail dispatch
    vibe.send_mail({
        to: "sales@agency.com",
        subject: "New Lead: " + data.subject,
        template: "email/contact_notification.jet", // Uses Jet for email bodies
        vars: {
            "name": data.name,
            "message": data.message
        }
    })
    
    return { "status": "success" }
}
```

### 10.5 High-Performance Rendering (Jet for Email)

VibeCMS utilizes the same **Jet Template Engine** used for front-end rendering to generate email bodies. This ensures:
*   **Speed:** Near-instantaneous string interpolation for email templates.
*   **Consistency:** Developers can reuse CSS logic or partials from the main theme inside email layouts (e.g., brand headers/footers).
*   **Locality:** Email templates are stored within the theme directory: `/themes/{name}/layouts/email/`.

### 10.6 Reliability and Edge Cases

*   **Provider Fallback:** If the primary provider (e.g., Resend) returns a 4xx or 5xx error, the system remains in a `failed` state in the log. The internal Cron system (Section 11) can be configured to retry `failed` logs every 15 minutes up to 3 times.
*   **Rate Limiting:** To prevent the CMS from being used as a spam relay, the communication layer includes a rate-limiter that caps outgoing mail at a configurable threshold (default: 100 emails/hour) unless overridden in `license.json`.
*   **Attachment Handling:** Attachments are streamed directly from **S3-compatible storage** to the mail provider. The CMS binary does not buffer large files in memory, preserving the 50ms performance profile even during heavy media-heavy mail tasks.
*   **GDPR/Privacy:** A "Log Retention" setting allows agencies to automatically purge `body_html` from logs older than 30 days while keeping metadata for health monitoring, ensuring compliance with data privacy regulations.

## Section 11: Task Scheduling and Internal Cron System

VibeCMS utilizes a high-precision, low-overhead internal task scheduler designed to maintain the project's sub-50ms TTFB target by offloading non-critical, long-running, or resource-intensive operations to a background sidecar sequence. This system is implemented as a specialized Go routine manager that functions independently of the request-response lifecycle of the Fiber/Echo web server.

### 11.1 Architecture & Process Separation
The Task Scheduler is architected as an "Internal sidecar process" within the single Go binary. Upon application boot, the scheduler initializes a prioritized work queue and a set of worker pools. 

*   **Concurrency Control:** The scheduler uses a coordinated `context.Context` for graceful shutdowns and a `sync.WaitGroup` to ensure that active tasks (such as database dumps) complete before the process terminates.
*   **Isolation:** Tasks are executed in a separate memory space from the web request handlers. CPU-intensive operations (e.g., WebP image optimization or AI metadata generation) are restricted by a configurable worker pool limit (defaulting to `runtime.NumCPU() / 2`) to ensure that the primary web thread always has sufficient headroom to meet performance targets.

### 11.2 Task Types and Scheduling Logic
The system supports three distinct categories of scheduled operations:

| Task Category | Example Operations | Trigger Mechanism |
| :--- | :--- | :--- |
| **System Maintenance** | `pg_dump`, Log Rotation, License Verification | Fixed Interval (Cron Syntax) |
| **Content Operations** | AI SEO Suggestions, Link Checking | Event-Driven or Delayed |
| **Agency Workflows** | Health Heartbeats, Update Synchronizations | Programmatic API Trigger |

#### 11.2.1 Cron Syntax Support
The scheduler supports standard 5-6 digit Cron expressions (Seconds, Minutes, Hours, Day of Month, Month, Day of Week). 
*   **Example:** `0 0 2 * * *` (Runs a backup daily at 2:00 AM).
*   **Persistence:** Recurring tasks are defined in the `system_tasks` table, allowing administrators to modify schedules via the Admin UI without modifying the Go source or `.env` files.

### 11.3 Integration with Tengo Scripting (.tgo)
To achieve "Zero-Rebuild Extensibility," the cron system is exposed to the Tengo scripting engine. This allows agencies to script custom background logic that cannot be handled by standard CMS features.

*   **Scripted Tasks:** Users can place `.tgo` files in `/themes/{name}/scripts/cron/`. The internal scheduler automatically scans this directory and matches scripts to entries in the database.
*   **Global `vibe` Object Access:** Within a background Tengo script, the `vibe` object provides restricted access to:
    *   `vibe.mail.send()`: For automated reporting/alerts.
    *   `vibe.db.query()`: Read-only access to content nodes for reporting.
    *   `vibe.http.get()`: For fetching external data (e.g., exchange rates, remote weather APIs).

### 11.4 Core System-Level Task Definitions

#### 11.4.1 Automated Backups (`pg_dump --no-lock`)
To ensure zero downtime and consistency, the backup task executes a non-blocking PostgreSQL dump.
*   **Execution:** `pg_dump -U username -d vibecms_db --no-lock --format=custom -f /tmp/backup.dump`.
*   **S3-Compatible Upload:** Immediately following the dump, the file is streamed to the configured S3-compatible storage (e.g., R2, DigitalOcean Spaces, or MinIO for local dev) and deleted from the local `/tmp` directory.
*   **Retention Policy:** The task cleans up old backups on the S3 bucket based on the "Keep Last N" configuration.

#### 11.4.2 License Verification Worker
In accordance with the VibeCMS licensing model, an internal task runs every 24 hours (`license_verification_interval_hours: 24`).
*   **Logic:** The worker reads the local `license.json` file, extracts the asymmetric signature and domain, and performs an outbound HMAC-signed request to the central VibeCMS license server.
*   **Fallback:** If the check fails (Network timeout), the task retries every hour for 3 hours before flagging the instance. If the key is invalid, the task triggers a state change in the CMS to "Core Mode," disabling Pro-features (like this Cron system's UI) while keeping the public site's 50ms TTFB path active.

#### 11.4.3 Search Engine Maintenance
*   **Real-time Sitemap.xml:** While the sitemap is cached in-memory for public requests, a scheduled task performs a "deep crawl" of the `content_nodes` table every 6 hours to pre-generate the static indices and update the in-memory cache, ensuring no request ever triggers a database-heavy sitemap rebuild.

### 11.5 Monitoring and Error Handling
All task executions are logged to the `task_logs` table JSONB field for auditing via the Agency Management API.

*   **Structure of `task_logs`:**
    ```sql
    CREATE TABLE task_logs (
        id SERIAL PRIMARY KEY,
        task_name VARCHAR(255),
        status VARCHAR(50), -- 'success', 'failed', 'running'
        started_at TIMESTAMP,
        finished_at TIMESTAMP,
        error_message TEXT,
        execution_metadata JSONB -- Stores stats like "files_backed_up" or "email_count"
    );
    ```
*   **Self-Healing:** If a task remains in the 'running' state for longer than its defined `timeout_seconds` (stored in the task definition), the sidecar process will kill the associated Go routine, log a timeout error, and attempt a restart on the next scheduled interval.

### 11.6 Internal Health Heartbeat
For agencies managing hundreds of sites, the Cron system emits a "Heartbeat" payload to the `Agency Management API` endpoint. 
*   **Payload Data:** Current disk usage of S3 storage, last successful backup timestamp, license status, and average TTFB recorded over the last hour.
*   **Frequency:** Defaults to every 15 minutes, configurable per instance.

### 11.7 Developer Constraints & Edge Cases
1.  **Race Conditions:** Tasks modifying the same `JSONB` block data in `content_nodes` must implement optimistic locking via a `version` field.
2.  **Memory Limits:** For S3 uploads, the system must stream data using `io.Pipe()` rather than loading entire backup buffers into RAM to maintain the lightweight footprint of the Go binary.
3.  **Local Dev (MinIO):** During development, the Cron system detects the environment; if `ENV=development`, it utilizes the MinIO mock instead of attempting to reach production S3 buckets, ensuring that scheduled backup tasks do not fail in local environments.

## Section 12: Data Persistence and JSONB Schema-on-Read Strategy

VibeCMS utilizes PostgreSQL as its primary data store, leveraging the `JSONB` (Binary JSON) data type to balance the performance of a relational database with the flexibility of a document store. To achieve the **sub-50ms TTFB target**, the system avoids traditional heavy ORM abstractions and complex multi-table joins for content retrieval. Instead, it employs a **Schema-on-Read Strategy** with a specialized transformation layer.

### 12.1 The Universal Node Structure
The core of VibeCMS persistence is the `content_nodes` table. Every routable entity (Page, Blog Post, Product, Custom Entity) is stored as a row in this table. This flat structure ensures that the primary lookup—finding a page by its slug—is a single-index scan.

| Column | Type | Description |
| :--- | :--- | :--- |
| `id` | `UUID` | Primary Key (ULID-compatible for sortability). |
| `slug` | `TEXT` | Indexed URL path (e.g., `/about-us`). |
| `node_type` | `VARCHAR(50)` | Discriminator (e.g., `page`, `post`, `custom`). |
| `parent_id` | `UUID` | Self-referencing FK for hierarchical path resolution. |
| `locale` | `VARCHAR(5)` | ISO code (e.g., `en-US`, `sk-SK`). |
| `blocks_data` | `JSONB` | **Primary Storage**: Array of block objects. |
| `version_id` | `INT` | Incremental integer for Schema-on-Read versioning. |
| `seo_data` | `JSONB` | Metadata, OpenGraph, and Schema.org properties. |
| `published_at` | `TIMESTAMPTZ` | Nullable; used for scheduling and visibility. |

### 12.2 JSONB Content Modeling (blocks_data)
Inside the `blocks_data` field, content is stored as an ordered array of JSON objects. Each object must follow a strict schema defined by the theme's block definition.

**Storage Format Example:**
```json
[
  {
    "id": "blk_01H2",
    "type": "hero_section",
    "version": 1,
    "values": {
      "title": "Welcome to VibeCMS",
      "image_ref": "vibe_media_9921.webp",
      "cta_link": "/contact"
    }
  },
  {
    "type": "text_block",
    "version": 2,
    "values": {
      "content": "High performance Go-based CMS...",
      "alignment": "center"
    }
  }
]
```

### 12.3 Schema-on-Read Transformation Layer
To maintain a 50ms TTFB while allowing content structures to evolve without `ALTER TABLE` migrations, VibeCMS implements a **Transformation Layer** in Go. When data is fetched from the DB, it passes through a versioning pipeline before reaching the Jet rendering engine.

#### 12.3.1 Version Mapping Logic
Each block type has a corresponding `Map` in the Go backend or defined in `vibe.json` within the theme. If the `version` key in a block's JSON is lower than the current registration, the system applies a transformation.

```go
// Internal representation of the Transformation Layer
type BlockTransformer func(input map[string]interface{}) map[string]interface{}

var HeroTransformV1toV2 = func(input map[string]interface{}) map[string]interface{} {
    // Migration: rename 'cta_link' to 'primary_action_url'
    if val, ok := input["cta_link"]; ok {
        input["primary_action_url"] = val
        delete(input, "cta_link")
    }
    return input
}
```

#### 12.3.2 Benefits of this Strategy
1.  **Zero Downtime:** Changes to content structures (adding a field to a "Contact Form" block) do not require database locks.
2.  **Performance:** Transformations happen in-memory during the fetch phase, which is significantly faster than bulk-updating millions of JSON rows.
3.  **Auditability:** Content remains in its original state in the DB, while only the "Read" view is updated, preserving historical accuracy for versioning.

### 12.4 JSONB Indexing and Query Optimization
To ensure the `blocks_data` remains queryable for the Admin UI and Agency Monitoring API, VibeCMS uses **GIN (Generalized Inverted Index)** on specific paths.

**SQL Constraint / Indexing Policy:**
*   **Expression Index:** `CREATE INDEX idx_blocks_type ON content_nodes USING GIN ((blocks_data -> 'type'));`
*   This allows the Agency Dashboard to instantly find all instances of a specific block type (e.g., "Find all pages using the outdated 'LegacySlider' block").

### 12.5 Integrity and Validation (JSON-Schema First)
Data integrity is enforced at the **Application Layer** rather than the Database Layer. 
1.  **On-Save Validation:** Before committing to the `blocks_data` field, the Go backend validates the payload against a JSON Schema associated with that block type.
2.  **Zero-Rebuild Extensibility Hook:** The `vibe` global object in Tengo can intercept the save process to perform cross-field validation (e.g., "Ensure 'End Date' is after 'Start Date' in this Event block").

### 12.6 The "Point-in-Time" Recovery implementation
Versioning is handled via a shadow table approach to keep the primary `content_nodes` table lean.
*   **`content_node_versions`**: Stores full snapshots of `blocks_data` and `seo_data`.
*   **Persistence Trigger:** A version is created only when the "Publish" action is triggered in the Admin UI.
*   **Storage Optimization:** JSONB is compressed by PostgreSQL (TOAST), but for high-frequency updates, VibeCMS uses a "Diff" strategy in the internal sidecar process to prune versions older than 30 days unless marked as "Milestone."

### 12.7 Performance Constraints (Sub-50ms Path)
To maintain the required performance, the persistence layer adheres to the following constraints:
1.  **No Recursive CTEs in Production Routes:** URL path resolution is flattened in a `slug_cache` table or in-memory map.
2.  **Lean Payloads:** The `blocks_data` field is limited to 2MB per node. Media handles (UUIDs/filenames) are stored, never base64 blobs.
3.  **Connection Pooling:** Fiber/Echo instances use a strictly tuned `pgx` pool with `MaxConns` calculated as `(2 * CPU cores) + 1` to prevent context-switching overhead.

## Section 13: Security, RBAC, and License Key Enforcement

VibeCMS implements a multi-layered security architecture designed to maintain a sub-50ms TTFB while providing robust protection for agency assets. This section details the authentication mechanisms, the Role-Based Access Control (RBAC) engine, and the proprietary license enforcement system.

### 13.1 Authentication and Session Management

VibeCMS utilizes a secure-by-default session management system tailored for the Fiber/Echo ecosystem.

*   **Session Storage:** Sessions are stored in PostgreSQL using a dedicated `sessions` table to ensure persistence across application restarts.
*   **Cookie Security:**
    *   `HttpOnly`: true (prevents XSS-based cookie theft).
    *   `Secure`: true (enforced in production, requires HTTPS).
    *   `SameSite`: Strict.
*   **Password Hashing:** All user passwords are hashed using `argon2id` with a minimum memory cost of 64MB, parallelism of 2, and 3 iterations, ensuring resistance against GPU-based brute-force attacks.
*   **Brute-Force Protection:** The Admin UI includes a rate-limiting middleware that triggers a 30-second exponential backoff after 5 failed login attempts from a single IP.

### 13.2 Role-Based Access Control (RBAC)

VibeCMS employs a granular RBAC system designed to balance agency control with client ease of use. Permissions are enforced at the middleware level for API routes and at the template level for the Admin UI (using Alpine.js and Jet conditions).

#### 13.2.1 Defined Roles and Permissions
| Role | Description | Permissions |
| :--- | :--- | :--- |
| **Admin** | The site owner or lead developer. | Full access to all settings, user management, Tengo script editing, and database backups. |
| **Agency-Manager** | External oversight role for maintenance. | Access to Health Monitoring APIs, log viewing, and license management. Cannot edit theme files. |
| **Editor** | Content-focused user. | Node creation/editing, Media Manager access, SEO metadata entry. Blocked from system settings and Tengo scripts. |

#### 13.2.2 Permission Enforcement Logic
RBAC checks are handled by a Go-native `PermissionGuard` middleware. This service cross-references the user's role against a bitmask of required permissions for the requested endpoint.

```go
// Example Permission Check (Internal Logic)
func (s *SecurityService) HasPermission(userRole string, action string) bool {
    permissions := map[string][]string{
        "Admin":          {"*"},
        "Agency-Manager": {"read:health", "read:logs", "manage:license"},
        "Editor":         {"create:nodes", "update:nodes", "upload:media", "manage:seo"},
    }
    
    allowedActions := permissions[userRole]
    for _, a := range allowedActions {
        if a == "*" || a == action {
            return true
        }
    }
    return false
}
```

### 13.3 License Key Enforcement

VibeCMS follows a "Paid key per domain" model. To achieve the 50ms TTFB target, license verification must never block the public-facing request pipeline.

#### 13.3.1 The License File (`license.json`)
Every instance requires a `license.json` file in the root directory. This file contains a cryptographically signed payload from the VibeCMS central authority.

```json
{
  "license_key": "VIBE-XXXX-XXXX-XXXX",
  "domain": "example.com",
  "issued_at": "2023-10-01T12:00:00Z",
  "features": ["agency_api", "ai_seo", "cron_backups"],
  "signature": "MEYCIQC...[Base64 Signature]..."
}
```

#### 13.3.2 Verification Mechanism
1.  **Boot Phase:** On application startup, the system performs a **Local Asymmetric Signature Verification**. It uses a hardcoded Public Key to verify that the `license.json` was signed by VibeCMS and matches the current deployment domain.
2.  **Public Site Integrity:** If verification fails, the public site remains online to prevent SEO damage. However, the system enters "Core Mode."
3.  **Core Mode Restrictions:** In "Core Mode," the following features are disabled:
    *   Agency Management API endpoints.
    *   AI-generated SEO metadata suggestions.
    *   Automated S3 backups via the internal Cron sidecar.
    *   Native Resend.com integration (reverts to standard SMTP).
4.  **Phone-Home Interval:** An internal sidecar process performs a non-blocking background check against `vibe-cms.com/api/verify` every **24 hours**. This updates the local `license.json` and ensures the key has not been revoked or blacklisted.

### 13.4 API Security (Agency & Health Monitoring)

The Centralized API (established in Section 9) is secured via **API Key-based authentication** (X-API-KEY header). 

*   **Key Rotation:** Managed through the Admin UI by users with the `Admin` or `Agency-Manager` role.
*   **IP Whitelisting:** The Agency API can be optionally restricted to specific CIDR blocks to prevent exposure to the public internet.
*   **Audit Logging:** Every access to the Agency API is logged in the `system_audit_log` table, recording the timestamp, requesting IP, and the status of the request.

### 13.5 Tengo Scripting Sandbox Security

Because Tengo scripts (`.tgo`) can execute logic during the rendering pipeline, strict sandboxing is enforced:
*   **Global Object (`vibe`):** Only the `vibe` object is injectable. It provides high-level helpers (e.g., `vibe.get_node_data()`) but forbids low-level OS access.
*   **Prohibited Modules:** The `os`, `exec`, and `unsafe` Tengo modules are stripped from the VM during execution.
*   **Resource Limits:** Each script execution is capped at 100ms of CPU time and 10MB of memory allocation to prevent malicious or poorly written scripts from degrading the 50ms TTFB target.

### 13.6 Data Persistence Security (JSONB)
To prevent "Insecure Direct Object Reference" (IDOR) within the JSONB payload:
*   **Schema-on-Read Sanitization:** The transformation layer automatically filters out any keys prefixed with `_private_` before passing data to the Jet templating engine, ensuring internal metadata is never leaked to the frontend.
*   **SQL Injection:** All queries to the JSONB fields use PostgreSQL parameterized inputs through the GORM driver, preventing injection attacks via block data.

## Section 14: Backup and Recovery (Postgres + S3-Compatible Storage)

VibeCMS utilizes a robust, non-blocking backup and recovery architecture designed to protect both the relational integrity of the PostgreSQL database and the physical binary objects stored in S3-compatible environments. To maintain the project's sub-50ms TTFB target, all backup operations are handled by the **Internal Cron System** (the sidecar process), ensuring that intensive I/O operations never compete with the primary Go (Fiber/Echo) request handling threads.

### 14.1. Tactical Strategy: Non-Blocking Snapshots
The core philosophy of VibeCMS backups is "Stateless Application, Stateful Backups." Since the Go binary is stateless, the backup system focuses exclusively on two targets:
1.  **The Database:** All node structures, `blocks_data` (JSONB), SEO metadata, and system logs.
2.  **The S3 Assets:** To ensure point-in-time recovery, asset manifests are backed up alongside the database.

#### DB Dump Execution
To prevent table locking which would spike TTFB during a backup cycle, the system mandates the use of `pg_dump --no-lock`. 
- **Format:** Custom Archive format (`-Fc`), allowing for parallel restores and smaller file sizes.
- **Compression:** Zstd compression level 3 (balanced for speed and ratio).
- **Naming Convention:** `vibecms_db_{domain}_{timestamp}.dump.zstd`

### 14.2. Storage Providers and S3 Configuration
VibeCMS supports any S3-compatible API (AWS, DigitalOcean Spaces, Cloudflare R2). For local development and CI/CD testing, **MinIO** is the mandated mock.

**Global Backup Configuration (`config.yaml`):**
```yaml
backup:
  schedule: "0 2 * * *" # Daily at 2 AM
  retention_days: 30
  provider:
    type: "s3"
    endpoint: "s3.amazonaws.com"
    bucket: "vibe-backups-prod"
    region: "us-east-1"
    access_key: "${S3_BACKUP_KEY}"
    secret_key: "${S3_BACKUP_SECRET}"
    use_ssl: true
  encryption:
    enabled: true
    passphrase: "${BACKUP_ENCRYPTION_KEY}" # AES-256-GCM
```

### 14.3. Automated Backup Workflow (The Cron Sidecar)
The internal sidecar process executes the following sequence when a backup task is triggered:

1.  **Pre-flight Check:** Verifies database connectivity and calculates the estimated size of the `content_nodes` table.
2.  **Streaming Dump:**
    - The process spawns a `pg_dump` worker.
    - Instead of writing a large temporary file to the local disk (limited in single-instance deployments), the output is piped directly into a `MultiWriter` that handles both the Zstd compression and the S3 `PutObject` multipart upload stream.
3.  **Asset Syncing (Optional):** While S3 storage is generally durable, VibeCMS can be configured to perform a bucket-to-bucket sync for "Golden Backups" to a secondary region.
4.  **Metadata Manifest:** A `manifest.json` is generated containing:
    - VibeCMS Version (for Schema-on-Read compatibility).
    - Database Schema Version.
    - Total Block Count.
    - Checksum (SHA-256).
5.  **Cleanup:** The sidecar queries the S3 bucket for files older than `retention_days` and issues a `DeleteObjects` command to minimize storage costs.

### 14.4. Recovery Procedures
Recovery is handled via a dedicated CLI flag or a high-privilege Admin UI action. Because of the **Schema-on-Read** versioning strategy, a restore from an older version of VibeCMS will still function, as the transformation layer handles JSONB mapping at the next request.

#### Full Instance Recovery Logic
```go
// Simplified Disaster Recovery Flow
func RestoreInstance(backupPath string) error {
    // 1. Enter Maintenance Mode (Set Fiber to return 503)
    system.ToggleMaintenance(true)
    
    // 2. Clear current content_nodes and system tables
    db.Exec("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    
    // 3. Stream from S3 to pg_restore
    reader, _ := s3Client.GetObject(backupPath)
    cmd := exec.Command("pg_restore", "--no-owner", "-d", dsn)
    cmd.Stdin = reader
    
    // 4. Verify Integrity
    if err := db.Ping(); err != nil {
        return RestoreError{"Database corrupted post-restore"}
    }
    
    // 5. Exit Maintenance Mode
    system.ToggleMaintenance(false)
    return nil
}
```

### 14.5. Agency Monitoring Integration
Per Section 9 (Agency Management API), every backup event emits a webhook to the agency's central dashboard.
- **Success Event:** Payload includes the backup size and the duration of the dump.
- **Failure Event:** Payload includes a stack trace from the sidecar and the specific PostgreSQL error code (e.g., `57P01` for admin shutdown).
- **Health Check:** The monitoring API reports `last_successful_backup_at`. If this exceeds 28 hours, the agency dashboard flags the instance as "CRITICAL."

### 14.6. Edge Cases and Constraints
| Scenario | VibeCMS Logic |
| :--- | :--- |
| **Insufficient S3 Permissions** | Side car retries 3 times with exponential backoff, then logs a "Critical Maintenance" event in the DB. |
| **Large Alt-Text/JSONB Blobs** | `blocks_data` exceeds 1GB: Backup utilizes `pg_dump`'s blob-size optimizations to prevent memory exhaustion. |
| **Network Interruption** | Multipart uploads are used for S3. If the stream breaks, the sidecar cleans up the partial upload to prevent "hidden" S3 costs. |
| **Recovery of Scripting Logic** | Since Tengo `.tgo` files are in the theme folder, they are not in the DB dump. Recovery requires a Git pull or a separate zip-backup of the `/themes/` directory to S3. |

### 14.7. Local/Development Backup Mocking
For developers using MinIO, the `vibe` global object in Tengo allows for manual triggers of the backup logic during theme development via:
`vibe.system.trigger_backup("local-dev-snapshot")`
This ensures that even during rapid prototyping of `.tgo` scripts or JSONB schema changes, developers have a "save point" for their database state.

## Section 15: Multi-Language Support and Localization Routing

VibeCMS provides a native, high-performance architecture for multi-language content delivery. Unlike traditional CMS platforms that rely on third-party plugins or complex table joins, VibeCMS treats localization as a first-class citizen of the `content_nodes` table and the routing engine. The system is designed to maintain the **sub-50ms TTFB target** regardless of the number of active locales by utilizing efficient indexed lookups and in-memory routing maps.

### 15.1. Localization Strategy: The "Node-Per-Locale" Model

VibeCMS employs a "Node-Per-Locale" strategy for content persistence. This ensures that each localized version of a page is a distinct entry in the `content_nodes` table, allowing for granular SEO control, independent block structures (if needed), and simplified querying.

*   **Source Linking:** Every localized node contains a `source_id` field (pointing to the ID of the primary language version) and a `locale_code` field (e.g., `en-US`, `de-DE`).
*   **Data Inheritance:** By default, when a new locale is created for a node, the `blocks_data` (JSONB) is copied from the source. The system utilizes the **Schema-on-Read Transformation Layer** to handle fields that should remain synced across all languages (e.g., product IDs or SKU references) vs. those that must be translated (e.g., body text, headers).
*   **Status Management:** Each locale has its own `status` (Draft, Published, Archived), allowing a page to be live in English while still under translation for the Spanish market.

### 15.2. Routing and URL Resolution Strategies

VibeCMS supports two primary localization routing patterns, configurable in the system settings. The routing engine resolves these patterns before the "Vibe Loop" (Public Rendering) begins.

#### 15.2.1. Path-Based Routing (Subdirectories)
The most common deployment for international SEO.
*   **Format:** `domain.com/{locale}/{slug}`
*   **Root Handling:** The default locale (e.g., English) can be configured to reside at the root (`/services`) or with a prefix (`/en/services`).
*   **Fiber/Echo Middleware:** A specialized localization middleware intercepts the request, strips the locale prefix, set the `vibe.CurrentLocale` context, and passes the remaining path to the node resolver.

#### 15.2.2. Domain/TLD-Based Routing
Used for maximum regional targeting.
*   **Format:** `domain.sk/cesta` and `domain.at/weg`
*   **Resolution Logic:** The system maps the `Host` header to a specific `locale_code`.
*   **Cross-Domain Linking:** Even with 1:1 deployment, VibeCMS allows the `license.json` to authorize multiple TLDs if they serve the same instance's localized content.

### 15.3. The Localization Context and Global Object

During the rendering pipeline, the `vibe` global object is populated with localization-specific data available to both **Tengo scripts** and **Jet templates**.

```go
// Internal Context Structure passed to Jet/Tengo
type LocaleContext struct {
    Code           string             // e.g., "fr-FR"
    Direction      string             // "ltr" or "rtl"
    Currency       string             // e.g., "EUR"
    IsDefault      bool               // Is this the primary site language?
    Translations   map[string]string  // Micro-copy/UI strings
    AltVersions    []AltVersion       // For hreflang generation
}
```

### 15.4. Admin UI: Side-by-Side Translation Interface

The VibeCMS Admin UI uses **HTMX and Alpine.js** to provide a seamless translation workflow without page reloads.

1.  **Context Switching:** A locale-switcher in the top bar allows editors to toggle between languages.
2.  **Comparison Mode:** An "Overlay" or "Side-by-Side" mode uses Alpine.js to fetch the JSONB data of the primary language and display it as read-only labels next to the active translation fields.
3.  **AI-Generated Translation:** Leveraging the **AI-integration scope**, editors can click a "Translate Block" button. This sends the specific block's `blocks_data` JSON to an LLM with instructions to translate only the text-string values while preserving the JSON keys and structure.

### 15.5. Technical SEO and Internationalization

VibeCMS automates the complex requirements of international SEO to ensure search engines correctly index localized versions.

*   **Hreflang Automation:** The system automatically generates `<link rel="alternate" hreflang="..." href="...">` tags in the `<head>` of `main.jet`. It queries the `content_nodes` table for all nodes sharing the same `source_id` to build the full alternate map.
*   **Sitemap Integration:** The **In-memory Sitemap.xml** includes `<xhtml:link>` tags for all localized versions of a URL, ensuring Google receives a complete picture of the site structure in a single crawl.
*   **Locale-Specific Slugs:** Slugs are unique per locale. `domain.com/en/about-us` and `domain.com/de/ueber-uns` point to the same functional node group but maintained as distinct entries for SEO keywords.

### 15.6. UI String Management (i18n)

For hard-coded theme strings (e.g., "Read More", "Submit Form"), VibeCMS uses a JSON-based translation system within the theme directory: `/themes/{name}/lang/{locale}.json`.

**Example `en-US.json`:**
```json
{
  "blog.read_more": "Read more about this article",
  "contact.success": "Thank you for your message!"
}
```

**Usage in Jet Template:**
```jet
<button>{{ i18n("blog.read_more") }}</button>
```

**Usage in Tengo Script (.tgo):**
```tengo
if vibe.post_data.email == "" {
    vibe.set_error(vibe.i18n("contact.error_email"))
}
```

### 15.7. Edge Case: Content Fallback Logic

In instances where a node is not yet translated, VibeCMS allows for a "Fallback to Primary" configuration.
*   **Routing Behavior:** If a user visits `/fr/new-product` and the French node does not exist, the system can be configured to:
    1.  Return a 404 (Default for strict SEO).
    2.  Serve the English version but keep the `/fr/` URL (Shadowing).
    3.  Redirect (302) to the English URL.
*   **Performance Impact:** This check is performed via a `Map[string]int` in-memory lookup table that stores `Path:NodeID` mappings, ensuring that even with fallback logic, the **sub-50ms TTFB** is not compromised.

