# VibeCMS Security Hardening Documentation

## About This Document

**Purpose:** Security controls, hardening checklist, and threat model for the VibeCMS application. Defines the minimum security bar that must be met before production launch.

**How AI tools should use this:** Apply these controls when generating authentication code, API handlers, database queries, and infrastructure configuration; flag any generated code that violates a control listed here.

**Consistency requirements:** Security boundaries must align with architecture.md; authentication model must match api-spec.md auth requirements; sensitive data fields must match database-schema.md column definitions.

VibeCMS is built for high-performance agency deployments where speed and security must coexist. Since each instance is a standalone Go binary managing sensitive client data and third-party integrations (S3, Resend, SEO APIs), we prioritize a "Defense in Depth" approach. This document outlines how we protect the sub-50ms rendering path while securing the administrative and agency management layers against common web vulnerabilities and supply-chain attacks.

---

### Threat Model

| Threat | Affected Component | Likelihood | Impact | Mitigation |
|--------|--------------------|------------|--------|------------|
| **Tengo Script Escape** | Tengo VM / Go Runtime | Medium | Critical | Strict resource sandboxing (4MB RAM, 15ms timeout) and removal of `os`, `exec`, and `io` modules from the VM. |
| **JSONB Injection** | PostgreSQL / Block Editor | Low | High | Use of GORM/pgx parameterized queries; strict JSON-Schema validation of all `blocks_data` before persistence. |
| **Agency Key Exposure** | Management API | Medium | High | AES-256-GCM encryption of keys at rest; CIDR IP whitelisting for `/api/v1/management` endpoints. |
| **Media XSS** | Media Manager / WebP Pipeline | Medium | Medium | Automated metadata stripping via `libvips`; Content Security Policy (CSP) restricting object-src. |
| **License Key Spoofing** | Licensing Worker | High | Medium | Asynchronous local asymmetric signature verification using embedded public keys. |
| **Session Hijacking** | Admin UI / Fiber Auth | Medium | High | `HttpOnly`, `Secure`, `SameSite=Strict` cookies; session pinning to IP and User-Agent strings. |

---

### Authentication Controls

Based on the specifications in `api-spec.md`, VibeCMS implements a dual-stack authentication model:

*   **Administrative Sessions (Human):**
    *   **Mechanism:** Stateful sessions stored in the `sessions` PostgreSQL table.
    *   **Hashing:** Argon2id (Memory: 64MB, Iterations: 3, Parallelism: 2).
    *   **Token Storage:** Cookie-based (`vibe_session`).
    *   **Security Flags:** `HttpOnly=true`, `Secure=true`, `SameSite=Strict`.
    *   **Expiry:** 24 hours (Hard expiry), no sliding window for elevated roles.
    *   **Brute-Force Protection:** Lockout after 5 failed attempts (`locked_until` field); exponential backoff (2^n minutes).
*   **Agency Management (M2M):**
    *   **Mechanism:** Static API Key via `X-Vibe-Agency-Key` header.
    *   **Entropy:** Minimum 48-character high-entropy base64 string.
    *   **Storage:** AES-256-GCM encrypted in `system_settings`.
    *   **Verification:** `subtle.ConstantTimeCompare` to prevent timing attacks.

---

### Authorization Controls

Access control is enforced via a bitmask-based RBAC system defined in `database-schema.md`.

| Role | Access Level | Enforcement Mechanism | Unauthorized Response |
|------|--------------|-----------------------|-----------------------|
| **Public** | `GET /` (and slugs) | Route-level bypass | 404 Not Found (to hide existence) |
| **Editor** | `/admin/nodes`, `/admin/media` | Fiber Middleware (Session + Bitmask) | 403 Forbidden: `{"error": "insufficient_permissions"}` |
| **Agency-Manager**| `/api/v1/management` | Header Check + CIDR Whitelist | 401 Unauthorized |
| **Admin** | Full System Access | Fiber Middleware (Session + Bitmask) | 403 Forbidden |

---

### Input Validation Checklist

Every API endpoint must validate input against the following constraints before processing:

| Endpoint | Field | Allowed Type/Format | Max Length | Error |
|----------|-------|---------------------|------------|-------|
| `POST /admin/api/nodes` | `slug` | Regex `^[a-z0-9-]+$` | 255 chars | 422 Unprocessable |
| `PATCH /admin/api/nodes/:id` | `blocks_data` | Valid JSON Array (JSON-Schema) | 2MB | 413 Payload Too Large |
| `POST /admin/api/media/upload`| `file` | MIME: `image/webp`, `image/jpeg` | 10MB | 415 Unsupported Media Type |
| `POST /api/v1/management/backups`| `storage_provider`| Enum: `s3`, `r2`, `minio` | 20 chars | 400 Bad Request |
| `GET /api/v1/management/logs` | `since` | RFC3339 Timestamp | 30 chars | 400 Bad Request |

---

### Rate Limiting

Rate limiting is enforced at the Fiber middleware level using a Redis-compatible internal shareable memory store.

*   **Public Content Path:** 100 requests / 1s / IP.
    *   *Exceeded:* `429 Too Many Requests`. Header: `Retry-After`.
*   **Admin Login (`POST /admin/login`):** 5 requests / 1 minute / IP.
    *   *Storage Backend:* Redis/In-memory key: `rate_limit:auth:ip_address`.
*   **Agency Management API:** 10 requests / 1s / Agency Key.
*   **AI Suggestion Endpoints:** 3 requests / 1 minute / User ID.

---

### Secrets Management

| Secret Category | Storage Location | Access Level | Rotation Policy |
|-----------------|------------------|--------------|-----------------|
| **Database DSN** | Environment Var (`DATABASE_URL`) | Go Runtime | On Infrastructure Change |
| **S3/R2 Credentials** | Encrypted `system_settings` (AES-256-GCM)| Go Task Worker | Every 90 Days |
| **Resend API Key** | Encrypted `system_settings` (AES-256-GCM)| Mail Dispatcher | If compromised / Yearly |
| **Master Encryption Key**| Environment Var (`VIBE_MASTER_KEY`) | Go Runtime Core| Primary Setup Only |

**Compromise Remediation:** 
1. Rotate `VIBE_MASTER_KEY` in environment.
2. Binary re-encrypts `system_settings` on next boot.
3. Invalidate all records in `table_sessions`.

---

### Pre-Launch Security Checklist

1.  [ ] **Not started**: Verify `VIBE_MASTER_KEY` is not the default value and meets 32-byte entropy.
2.  [ ] **Not started**: Confirm `libvips` is configured to strip EXIF/IPTC metadata on all WebP conversions.
3.  [ ] **Not started**: Run `gosec ./...` and ensure zero G104-G601 vulnerabilities are reported.
4.  [ ] **Not started**: Manually test Tengo VM sandbox by attempting an `os.Open("/etc/passwd")` call in a test script.
5.  [ ] **Not started**: Verify PostgreSQL user has only `CONNECT`, `SELECT`, `INSERT`, `UPDATE`, `DELETE` on the `vibe_db` schema (no `SUPERUSER`).
6.  [ ] **Not started**: Ensure all API responses include `X-Content-Type-Options: nosniff` and `X-Frame-Options: DENY`.
7.  [ ] **Not started**: Validate that `pg_dump` backups are encrypted with `AES-256-GCM` before being sent to S3.
8.  [ ] **Not started**: Test session revocation by deleting a row in `table_sessions` and confirming immediate 401 on the next admin request.