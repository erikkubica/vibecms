# VibeCMS Technology Stack

## About This Document

**Purpose:** Justified technology selections for this specific project. Establishes the implementation boundaries all other technical documents must respect.

**How AI tools should use this:** Use only the technologies listed here when generating code or configurations; do not introduce unlisted libraries.

**Consistency requirements:** Technology choices must be compatible with the architecture in architecture.md; directory conventions must match folder-structure.md.

VibeCMS is engineered for extreme performance and agency-scale manageability. The stack focuses on Go's mechanical sympathy to achieve a sub-50ms Time to First Byte (TTFB), while utilizing modern hypermedia patterns (HTMX/Alpine.js) to keep the administrative interface lightweight and maintainable. By choosing a Schema-on-Read approach with PostgreSQL JSONB, we provide the flexibility of a headless CMS with the speed of a compiled static site generator.

---

### Integration Map

```mermaid
graph TD
    subgraph "Client Layer"
        Browser["Web Browser (HTMX + Alpine.js 3.14.x)"]
    end

    subgraph "Application Layer (Go 1.22.x)"
        Fiber["Fiber 2.52.x / Echo 4.12.x"]
        Jet["Jet Engine 6.0.x"]
        Tengo["Tengo VM 2.13.x"]
        Templ["Templ 0.2.x"]
    end

    subgraph "Persistence & Storage"
        Postgres[("PostgreSQL 16.x + JSONB")]
        S3["S3-Compatible Storage (R2/Spaces/MinIO)"]
    end

    subgraph "External Services"
        Resend["Resend API / SMTP"]
        SEO_API["Ahrefs / Semrush API"]
    end

    %% Connections
    Browser -- "HTTP/REST & HTML Fragments" --> Fiber
    Fiber -- "Compiled Bytecode" --> Jet
    Fiber -- "Sandbox Execution" --> Tengo
    Fiber -- "Type-safe Components" --> Templ
    Fiber -- "SQL / pgx" --> Postgres
    Fiber -- "S3 SDK / HTTPS" --> S3
    Fiber -- "HTTPS / JSON" --> Resend
    Fiber -- "HTTPS / JSON" --> SEO_API
    Jet -- "npm import (Alpine/HTMX)" --> Browser
```

---

### Decision Log

| Technology Layer | Choice | Alternatives Considered | Rationale |
|-----------------|--------|------------------------|-----------|
| **Runtime** | Go 1.22.x | Node.js, Rust | **STATED:** Required for mechanical sympathy and hitting the sub-50ms TTFB target while maintaining high developer velocity. |
| **Web Framework** | Fiber 2.52.x | Gin, Standard Library | **STATED:** Fiber (fasthttp-based) provides the lowest allocation overhead for high-concurrency agency sites. |
| **Database** | PostgreSQL 16.x | MongoDB, MySQL | **STATED:** Required for robust JSONB support to handle block-based content and ACID compliance for agency data. |
| **Frontend Interactivity** | HTMX 2.0.x & Alpine.js 3.14.x | React, Vue.js | **STATED:** Eliminates SPA bloat. Aligns with the "AI-native" goal by keeping state on the server (Hypermedia). |
| **Public Templating** | Jet 6.0.x | html/template, Plush | **STATED:** Jet compiles to Go bytecode; it is significantly faster than standard templates and offers a Twig-like syntax. |
| **Admin Components** | Templ 0.2.x | Pure HTML strings | **STATED:** Provides type-safe Go components for the complex Admin UI, catching errors at compile-time instead of runtime. |
| **Scripting Engine** | Tengo 2.13.x | Lua, Starlark, WASM | **STATED:** Tengo is written in Go, has a Go-like syntax familiar to the target audience, and is highly performant for sandbox logic. |
| **Media Storage** | S3-Compatible (AWS/R2) | Local Disk, Cloudinary | **STATED:** Ensures a stateless binary. MinIO 2024.x is mandated for local development parity. |
| **Communication** | Resend API & SMTP | SendGrid, Mailgun | **ARCHITECTED:** Resend is recommended for its modern Go SDK and superior developer experience for transactional mail logging. |
| **Image Processing** | libvips / bimg 1.1.x | Imaging (Go native) | **ARCHITECTED:** libvips is the industry standard for high-performance WebP/AVIF conversion with minimal memory footprint. |
| **Task Scheduling** | Internal Worker Pool | RabbitMQ, Redis/Celery | **ARCHITECTED:** To keep 1:1 deployments simple, an internal Go-routine based cron system avoids adding external infrastructure dependencies. |
| **Object Mapping** | SQL (pgx) + GORM 1.25.x | Ent, Sqlx | **ARCHITECTED:** GORM is used for complex Admin relations, while raw pgx is recommended for the high-speed public "Vibe Loop" fetch path. |

---

### Version Specifications

#### Backend (Go Ecosystem)
- **Go:** `1.22.x` (utilizing loop var fixes and performance improvements)
- **Fiber:** `v2.52.x` or **Echo:** `v4.12.x`
- **Tengo:** `v2.13.x`
- **Templ:** `v0.2.747`+
- **GORM:** `v1.25.x`
- **Jet Engine:** `v6.0.x`

#### Frontend (Admin UI)
- **HTMX:** `2.0.x`
- **Alpine.js:** `3.14.x`
- **SortableJS:** `1.15.x` (for block reordering)
- **Tiptap/ProseMirror:** `2.4.x` (for rich-text block fields)

#### Infrastructure & Tools
- **PostgreSQL:** `16.x` (Minimum 14.x for efficient JSONB subsampling)
- **MinIO (Local Dev):** `RELEASE.2024-x`
- **Docker Compose:** `2.27.x` (for standardized agency local environments)
- **Zstandard (Zstd):** `1.5.x` (for backup compression)