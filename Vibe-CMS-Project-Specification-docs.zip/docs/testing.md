# VibeCMS Testing Strategy

## About This Document

**Purpose:** Comprehensive testing strategy defining what to test, how to test it, and what coverage targets must be met before shipping.

**How AI tools should use this:** Use this document when generating test files; follow the testing patterns, naming conventions, and coverage requirements defined here.

**Consistency requirements:** Test scope must cover every endpoint in api-spec.md, every requirement in product-requirements.md, and every component in architecture.md; test database fixtures must use tables from database-schema.md.

VibeCMS is built on a promise of extreme performance and agency-grade reliability. To ensure we maintain a sub-50ms Time to First Byte (TTFB) while allowing for flexible, AI-native content structures, our testing strategy focuses heavily on the "Vibe Loop" and the integrity of JSONB data structures. We prioritize automated integration tests that simulate real-world agency deployments, ensuring that zero-rebuild extensions (Tengo scripts) and block-based schemas do not introduce regressions or performance bottlenecks.

---

### Testing Pyramid

For VibeCMS, the pyramid is weighted toward **Integration Tests**. Because the core value lies in the orchestration of Go, PostgreSQL JSONB, and the Tengo VM to produce high-speed HTML, testing these units in isolation provides less value than testing their combined output.

```text
      /  E2E  \      <- 5%  (Critical User Journeys: Login, Publish, Backup)
     /---------\
    /   Integ   \    <- 60% (API Endpoints, SQL/JSONB Queries, Tengo Execution)
   /-------------\
  /     Unit      \  <- 35% (Slug Generation, Image Math, Schema Validation)
 /_________________\
```

**Rationale:**
1.  **Integration Heavy:** Standard Unit tests fail to catch performance drifts in the Fiber/Postgres pipeline or memory leaks in the Tengo VM.
2.  **Lightweight E2E:** Since the Admin UI uses HTMX/Alpine.js (server-side state), most UI logic is implicitly covered by Integration tests of the returned HTML fragments.

---

### Unit Tests

Unit tests focus on the purely algorithmic components of the CMS.

*   **URL & Slug Utilities:** Test `vibe.slugify()` and locale-aware path builders. Cover edge cases like special characters, duplicate prevention logic, and reserved keywords.
*   **JSON-Schema Validator:** Test the logic that parses `blocks_data` against `schema.json`. Assert that extra fields are stripped and mandatory fields are present.
*   **Image Formulae:** Verify `libvips` wrapper logic for Aspect Ratio calculations and WebP quality thresholding.
*   **Tengo Sandbox Limits:** Assert that the VM correctly kills scripts exceeding `tengo_instruction_limit: 5000`.

**Minimum Coverage Target:** 90% for utility modules.

**Example Test Case:** 
*   **Component:** `slug_builder.go`
*   **Scenario:** Convert "My Post !!!" into a URL slug for the `sk` locale. 
*   **Assertion:** Assert that the result is `my-post` and does not conflict with local route prefixes.

---

### Integration Tests

Integration tests are the primary defense against performance regression. All integration tests must run against a real **Postgres 16+** and **MinIO** container.

*   **The Vibe Loop (Public Render):** Measure time to resolve a slug and render a complex page (20+ blocks). Assert that output HTML contains specific strings from the `blocks_data`.
*   **Postgres JSONB Operations:** Test `SemaRead` version transformations. Seed a v1 JSONB block and assert that the retrieval logic returns a valid v2 structure.
*   **Extensibility Hooks:** Trigger `pre_render.tgo` and assert that variables injected by the script appear in the `vibe.vars` map during Jet rendering.
*   **Database Fixtures:** Use `test_fixtures/` SQL files to seed standard roles (Admin, Editor) and a baseline site structure before each suite.

**Seeding Strategy:** Use a `cmd/test-seeder` that purges tables and applies `pg_dump` snapshots. Wrap tests in transactions that roll back to maintain state purity.

---

### End-to-End Tests

E2E tests use **Playwright** to simulate agency users interacting with the Admin UI and checking public site delivery.

1.  **Direct-to-Publish:** 
    *   **Start:** Admin Dashboard. 
    *   **Steps:** Create new Page -> Add "Hero" Block -> Input Text -> Click "Publish". 
    *   **Assertion:** Visiting the slug as an unauthenticated user returns `200 OK` with the matching text.
2.  **Asset Optimization Loop:** 
    *   **Start:** Media Manager. 
    *   **Steps:** Upload 5MB JPEG. 
    *   **Assertion:** Wait for SSE "Ready" event; verify the rendered `<img>` tag points to a `.webp` URL in S3/MinIO.
3.  **Agency Key Health Check:** 
    *   **Start:** External script. 
    *   **Steps:** Call `/api/v1/management/health` with a valid `X-Vibe-Agency-Key`. 
    *   **Assertion:** Response contains `latency_p95_ms` and `license_status: "valid"`.
4.  **License Expiry Lockdown:**
    *   **Start:** Expired Mock License.
    *   **Steps:** Attempt to access "AI SEO Suggestions".
    *   **Assertion:** UI displays a `402 Payment Required` toast via HTMX.
5.  **Point-in-Time Restore:**
    *   **Start:** Node History Tab.
    *   **Steps:** Select Version 2 -> Click "Restore".
    *   **Assertion:** Editor refreshes with Version 2 data; public page reflects the rollback.

---

### Test Data Strategy

*   **Factories:** Use Go factory functions to generate `ContentNode` structs with random UUIDs and valid JSONB block arrays.
*   **Isolation:** Each test suite runs in a unique Postgres `SCHEMA` to allow parallel execution in CI.
*   **Env Parity:** CI environments must use the `VIBE_MASTER_KEY` secret to test encrypted credential decryption in `system_settings`.
*   **S3 Mocking:** Use the `minio/minio` Docker image. Assert that files are physically written to the `processed/` prefix.

---

### Coverage Requirements

| Layer | Minimum Coverage | Measurement Tool |
|-------|-----------------|-----------------|
| **Unit** | 80% line coverage | `go test -cover` |
| **Integration** | 100% of API Endpoints | `go-test-report` / Newman |
| **E2E (P0)** | 100% of critical journeys | Playwright Test Report |
| **Tengo** | All theme-default scripts | Internal VM coverage tool |

---

### Running Tests

**Run all tests:**
```bash
make test
```

**Run Integration tests only (requires Docker):**
```bash
go test ./internal/integration/... -tags=integration
```

**Run specific test file with coverage:**
```bash
go test -v -cover ./internal/render/render_test.go
```

**CI Implementation:**
Tests run on every `Pull Request` to `main`. Integration tests only proceed if Unit tests pass. E2E tests run on a dedicated "Staging" workflow before a `Release` tag is finalized.